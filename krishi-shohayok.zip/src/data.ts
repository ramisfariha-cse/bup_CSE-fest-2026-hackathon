/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { DistrictWeather, CommunityPost } from "./types";

export const BANGLADESH_DISTRICTS = [
  "Dhaka (ঢাকা)", "Sylhet (সিলেট)", "Chittagong (চট্টগ্রাম)", "Rajshahi (রাজশাহী)",
  "Rangpur (রংপুর)", "Khulna (খুলনা)", "Barisal (বরিশাল)", "Mymensingh (ময়মনসিংহ)",
  "Bogra (বগুড়া)", "Jessore (যশোর)", "Comilla (কুমিল্লা)", "Dinajpur (দিনাজপুর)"
];

export const DISTRICT_WEATHER_DATA: Record<string, DistrictWeather> = {
  "Dhaka (ঢাকা)": {
    temp: 32,
    humidity: 78,
    rainfallChance: 40,
    conditionBN: "আংশিক মেঘলা",
    conditionEN: "Partly Cloudy",
    recommendationsBN: [
      "ধানের জমিতে অতিরিক্ত ইউরিয়া সার প্রয়োগ স্থগিত রাখুন।",
      "মাটিতে আর্দ্রতা পর্যাপ্ত থাকায় এখনই ধান কাটার উত্তম সময় নয়।"
    ],
    recommendationsEN: [
      "Suspend extra urea application on rice field for today.",
      "As soil moisture is adequate, not the ideal moment to harvest immediately."
    ]
  },
  "Sylhet (সিলেট)": {
    temp: 27,
    humidity: 92,
    rainfallChance: 85,
    conditionBN: "ভারী বৃষ্টি ও বজ্রঝড়",
    conditionEN: "Heavy Rain & Thundershowers",
    warning: {
      type: "flood",
      titleBN: "আকস্মিক বন্যা সতর্কীকরণ",
      titleEN: "Flash Flood Warning",
      severity: "high",
      messageBN: "পাহাড়ি ঢলের কারণে আগামী ২৪ ঘণ্টায় আকস্মিক বন্যার ঝুঁকি রয়েছে। জমির আইল উঁচু করুন এবং সেচ নালা পরিষ্কার রাখুন।",
      messageEN: "Risk of flash floods in next 24h due to hill runoff. Raise field bunds and clear irrigation drainage channels."
    },
    recommendationsBN: [
      "ফসল জমি থেকে অতিরিক্ত জল নিষ্কাশনের ব্যবস্থা রাখুন।",
      "পরিপক্ক ফসল ৮০% পেকে থাকলে দ্রুত কেটে ঘরে তোলার ব্যবস্থা করুন।"
    ],
    recommendationsEN: [
      "Ensure fast drainage of excess water from fields.",
      "Harvest semi-ripe crops (80% matured) immediately to avoid flood loss."
    ]
  },
  "Chittagong (চট্টগ্রাম)": {
    temp: 29,
    humidity: 88,
    rainfallChance: 70,
    conditionBN: "ঝড়ো হাওয়া ও বৃষ্টি",
    conditionEN: "Stormy Wind & Rain",
    warning: {
      type: "cyclone",
      titleBN: "সতর্ক সংকেত - নিম্নচাপ",
      titleEN: "Low-Pressure Warning",
      severity: "medium",
      messageBN: "বঙ্গোপসাগরে সৃষ্ট নিম্নচাপের প্রভাবে উপকূলীয় অঞ্চলে ঝড়ো হাওয়া বইতে পারে। মৎস্য খামারিরা পুকুরের চারপাশে জাল দিন।",
      messageEN: "Low-pressure depression in Bay of Bengal might cause coastal gales. Fish farmers should cover ponds with nets."
    },
    recommendationsBN: [
      "মাছ চাষের পুকুরে পলি বা নেট ব্যবহার করুন যাতে তীব্র প্লাবনে মাছ ভেসে না যায়।",
      "কাঁচা ও নরম সবজি পরিপক্ক হলে এখনই সংগ্রহ করে নিন।"
    ],
    recommendationsEN: [
      "Install safety nets around fish ponds to prevent fish escape during heavy floods.",
      "Collect fresh and soft vegetables as soon as possible if they are matured."
    ]
  },
  "Rajshahi (রাজশাহী)": {
    temp: 39,
    humidity: 45,
    rainfallChance: 10,
    conditionBN: "তীব্র তাপপ্রবাহ",
    conditionEN: "Severe Heatwave",
    warning: {
      type: "heat",
      titleBN: "তীব্র রোদ ও খরা সতর্কবার্তা",
      titleEN: "Severe Heatwave Warning",
      severity: "high",
      messageBN: "রাজশাহী অঞ্চলে অতিমাত্রায় তাপপ্রবাহ চলছে। ফসলের ফুল ঝরা রোধে ভোরের দিকে বা সন্ধ্যায় পর্যাপ্ত সেচ দিন।",
      messageEN: "A severe heatwave is ongoing in Rajshahi. Water crops in early morning/evening to prevent flower drop."
    },
    recommendationsBN: [
      "ধান ও আম গাছে মালচিং এবং ঘন ঘন হালকা সেচ প্রদান করুন।",
      "মাইল্ড পোকামাকড়ের উপদ্রব এড়াতে জমিতে স্যাঁতসেঁতে আর্দ্রতা বজায় রাখুন।"
    ],
    recommendationsEN: [
      "Practice soil mulching and provide frequent light irrigation on crops.",
      "Maintain active crop moisture to repel mite and insect pressure."
    ]
  },
  "Rangpur (রংপুর)": {
    temp: 34,
    humidity: 62,
    rainfallChance: 25,
    conditionBN: "রৌদ্রোজ্জ্বল ও শুষ্ক",
    conditionEN: "Sunny & Dry",
    recommendationsBN: [
      "ভুট্টা ও আলু ফসলে সন্ধ্যার পরে সেচ দেওয়ার ব্যবস্থা করুন।",
      "মাটি পরীক্ষা ছাড়া অতিরিক্ত সার ব্যবহার করা থেকে বিরত থাকুন।"
    ],
    recommendationsEN: [
      "Irrigate maize and potato fields after evening to preserve moisture.",
      "Avoid applying fertilizer without doing proper soil testing first."
    ]
  }
};

export const INITIAL_COMMUNITY_POSTS: CommunityPost[] = [
  {
    id: "p1",
    author: "মোঃ রফিকুল ইসলাম",
    district: "সিলেট",
    crop: "ধান (Rice)",
    title: "ধানের পাতায় বাদামী রঙের ফোসকা দাগ দেখা যাচ্ছে, প্রতিকার কি?",
    content: "আমার আমন ধানের জমিতে কিছু পাতার উপর বাদামী ছোপ ছোপ ডিম্বাকৃতি দাগ দেখতে পাচ্ছি। গাছগুলো মাঝখান দিয়ে দুর্বল হয়ে যাচ্ছে। অগ্রজ কোনো কৃষি কর্মকর্তা ভাই কি একটু পরামর্শ দেবেন?",
    likes: 24,
    createdAt: "২০২৬-০৫-২৮",
    comments: [
      {
        id: "c1",
        author: "কৃষিবিদ ড. মাহফুজুল আলম",
        role: "expert",
        content: "লি ইসলাম ভাই, এটি ধানের বাদামী দাগ রোগ (Brown Spot) হতে পারে। প্রধানত নাইট্রোজেন বা পটাশ সারের ঘাটতি হলে এই রোগ বাড়ে। আপনি জমিতে পটাশ সার উপরি প্রয়োগ করুন। আক্রমণ তীব্র হলে ‘ন্যাটিভো’ বা ‘কার্বেন্ডাজিম’ গ্রুপের ভালো ছত্রাকনাশক স্প্রে করতে পারেন।",
        createdAt: "২০২৬-০৫-২৮"
      }
    ]
  },
  {
    id: "p2",
    author: "সুজন চন্দ্র বর্মন",
    district: "রংপুর",
    crop: "আলু (Potato)",
    title: "আলুর পাতা কুঁকড়ে যাওয়া রোগে কী স্প্রে করব?",
    content: "গত সপ্তাহে কুয়াশার পর থেকে আলুর পাতা নিচের দিক থেকে কুঁকড়ে যাচ্ছে এবং কালচে দাগ পড়ছে। এই আবহাওয়ায় কী প্রতিরোধক ব্যবহার করা জরুরি?",
    likes: 18,
    createdAt: "২০২৬-০৫-২৭",
    comments: [
      {
        id: "c2",
        author: "উপসহকারী কৃষি কর্মকর্তা সাবিনা ইয়াসমিন",
        role: "expert",
        content: "সুজন ভাই, কুয়াশা পরলে আলুতে লেট ব্লাইট হওয়ার ব্যাপক আশঙ্কা থাকে। আপনি প্রতি লিটার পানিতে কপার অক্সিক্লোরাইড ৫০ ডব্লউ পি ২ গ্রাম অথবা ম্যানকোজেব জাতীয় ম্যাটকো ২ গ্রাম মিশিয়ে ৭ দিন অন্তর ২ বার স্প্রে করুন। কুয়াশাচ্ছন্ন সকালগুলোতে ঠাণ্ডা পানি দিয়ে পাতা ধুয়ে দেবেন।",
        createdAt: "২০২৬-০৫-২৮"
      }
    ]
  }
];

export const CROPS_PRICE_TEMPLATES = [
  {
    id: "rice",
    nameBN: "চাল (মিনিক্যাট/নাজিরশাইল)",
    nameEN: "Rice (Miniket)",
    category: "crops",
    priceRange: [60, 68],
    unit: "কেজি",
    weeklyHistory: [58, 59, 61, 60, 62, 63, 64]
  },
  {
    id: "potato",
    nameBN: "গোল আলু (Potato)",
    nameEN: "Potato",
    category: "crops",
    priceRange: [38, 42],
    unit: "কেজি",
    weeklyHistory: [45, 43, 40, 39, 38, 40, 41]
  },
  {
    id: "jute",
    nameBN: "পাট (Jute Fiber)",
    nameEN: "Jute Fiber",
    category: "fiber",
    priceRange: [2800, 3200],
    unit: "মণ (৪০ কেজি)",
    weeklyHistory: [2900, 2950, 3010, 3100, 3050, 3150, 3200]
  },
  {
    id: "mango",
    nameBN: "হিমসাগর আম (Mango)",
    nameEN: "Mango (Himsagar)",
    category: "fruits",
    priceRange: [80, 100],
    unit: "কেজি",
    weeklyHistory: [110, 105, 95, 90, 85, 80, 85]
  },
  {
    id: "fish",
    nameBN: "রুই মাছ (Rui Fish)",
    nameEN: "Rui Fish",
    category: "fish",
    priceRange: [320, 380],
    unit: "কেজি",
    weeklyHistory: [340, 330, 345, 350, 360, 355, 370]
  }
];
