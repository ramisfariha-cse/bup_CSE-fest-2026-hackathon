/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

// Shared interfaces for Krishi Shohayok

export type Language = "BN" | "EN";
export type Theme = "light" | "dark";

export interface PlantDiseaseResult {
  diseaseNameBangla: string;
  diseaseNameEnglish: string;
  confidence: number;
  symptoms: string[];
  causes: string[];
  solutionsOrganic: string[];
  solutionsChemical: string[];
  prevention: string[];
}

export interface RecommendedCrop {
  cropName: string;
  suitability: string;
  expectedYield: string;
  farmingDuration: string;
}

export interface FertilizerItem {
  name: string;
  amount: string;
  timing: string;
}

export interface RecommendationResult {
  recommendedCrops: RecommendedCrop[];
  fertilizerRoutine: FertilizerItem[];
  costOptimizationTips: string[];
}

export interface MarketItem {
  market: string;
  distance: string;
  price: string;
}

export interface MarketTrendResult {
  currentPrice: string;
  lastWeekPrice: string;
  predictedNextMonthPrice: string;
  trendDirection: "UP" | "DOWN" | "STABLE";
  districtMarketNames: MarketItem[];
  aiAnalysis: string;
}

export interface WeatherWarning {
  type: "flood" | "cyclone" | "rainfall" | "heat" | "normal";
  titleBN: string;
  titleEN: string;
  severity: "high" | "medium" | "low";
  messageBN: string;
  messageEN: string;
}

export interface DistrictWeather {
  temp: number;
  humidity: number;
  rainfallChance: number;
  conditionBN: string;
  conditionEN: string;
  warning?: WeatherWarning;
  recommendationsBN: string[];
  recommendationsEN: string[];
}

export interface CommunityComment {
  id: string;
  author: string;
  role: "expert" | "farmer";
  content: string;
  createdAt: string;
}

export interface CommunityPost {
  id: string;
  author: string;
  district: string;
  crop: string;
  title: string;
  content: string;
  imageUrl?: string;
  likes: number;
  comments: CommunityComment[];
  createdAt: string;
}

export interface ChatMessage {
  id: string;
  sender: "user" | "assistant";
  text: string;
  timestamp: string;
}
