/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from "react";
import { motion, AnimatePresence } from "motion/react";
import {
  Camera,
  CloudSun,
  Spade,
  TrendingUp,
  Volume2,
  VolumeX,
  Users,
  Send,
  Sparkles,
  AlertOctagon,
  Languages,
  CheckCircle,
  HelpCircle,
  Search,
  PlusCircle,
  Smartphone,
  Check,
  ChevronRight,
  Info,
  Mic,
  MicOff,
  User,
  Activity,
  ThumbsUp,
  MessageSquare,
  DollarSign,
  Droplet
} from "lucide-react";
import { Language, CommunityPost, RecommendedCrop, FertilizerItem } from "./types";
import { BANGLADESH_DISTRICTS, DISTRICT_WEATHER_DATA, INITIAL_COMMUNITY_POSTS, CROPS_PRICE_TEMPLATES } from "./data";
import { DiseaseDetector } from "./components/DiseaseDetector";

export default function App() {
  const [lang, setLang] = useState<Language>("BN");
  const [offlineMode, setOfflineMode] = useState<boolean>(false);
  const [activeTab, setActiveTab] = useState<"disease" | "weather" | "soil" | "prices" | "assistant" | "community">("disease");
  
  // App variables
  const [selectedDistrict, setSelectedDistrict] = useState<string>("Dhaka (ঢাকা)");
  
  // 3D Tilt state for main visual header
  const [tilt, setTilt] = useState({ x: 0, y: 0 });
  const [isHovered, setIsHovered] = useState(false);

  // Fertilizer & Crop state
  const [soilType, setSoilType] = useState<string>("loamy");
  const [budgetStatus, setBudgetStatus] = useState<string>("Low Budget");
  const [season, setSeason] = useState<string>("Kharif-1");
  const [recommendLoad, setRecommendLoad] = useState<boolean>(false);
  const [recommendResult, setRecommendResult] = useState<any | null>(null);

  // Voice Chatbot state
  const [isRecording, setIsRecording] = useState<boolean>(false);
  const [userSpeechQuery, setUserSpeechQuery] = useState<string>("");
  const [chatHistory, setChatHistory] = useState<any[]>([
    { id: "1", sender: "assistant", text: "আসসালামু আলাইকুম রহমতুল্লাহ! আমি কৃষি সহকারী। ফসলের রোগ নির্ণয়, সার বা আবহাওয়া নিয়ে যেকোনো প্রশ্ন করতে পারেন।", timestamp: "এখন" }
  ]);
  const [chatInput, setChatInput] = useState<string>("");
  const [isChatLoading, setIsChatLoading] = useState<boolean>(false);
  const [voiceSynthesizerActive, setVoiceSynthesizerActive] = useState<boolean>(true);
  const [isSpeaking, setIsSpeaking] = useState<boolean>(false);

  // Market prices state
  const [selectedMarketCrop, setSelectedMarketCrop] = useState<string>("rice");
  const [marketResult, setMarketResult] = useState<any | null>(null);
  const [marketLoading, setMarketLoading] = useState<boolean>(false);

  // Community state
  const [communityPosts, setCommunityPosts] = useState<any[]>(INITIAL_COMMUNITY_POSTS);
  const [currentUserRole, setCurrentUserRole] = useState<"farmer" | "expert">("farmer");
  const [newPostTitle, setNewPostTitle] = useState<string>("");
  const [newPostContent, setNewPostContent] = useState<string>("");
  const [newPostCrop, setNewPostCrop] = useState<string>("ধান (Rice)");
  const [newCommentText, setNewCommentText] = useState<Record<string, string>>({});
  const [showCreatePost, setShowCreatePost] = useState<boolean>(false);

  // Floating notifications
  const [showNotificationAlert, setShowNotificationAlert] = useState<boolean>(true);

  // Web Speech synthesis ref
  const synthRef = useRef<SpeechSynthesis | null>(null);

  useEffect(() => {
    if (typeof window !== "undefined") {
      synthRef.current = window.speechSynthesis;
    }
  }, []);

  // Set up auto updates/fetches when district changes 
  useEffect(() => {
    analyzeMarketPrices();
  }, [selectedDistrict, selectedMarketCrop]);

  const speakText = (text: string) => {
    if (!voiceSynthesizerActive || !synthRef.current) return;
    synthRef.current.cancel(); // Stop ongoing speech if any
    const utt = new SpeechSynthesisUtterance(text);
    // Prefer Bengali/Bangla locally on device
    utt.lang = "bn-BD";
    utt.rate = 0.95;
    utt.onstart = () => setIsSpeaking(true);
    utt.onend = () => setIsSpeaking(false);
    utt.onerror = () => setIsSpeaking(false);
    synthRef.current.speak(utt);
  };

  const stopSpeaking = () => {
    if (synthRef.current) {
      synthRef.current.cancel();
      setIsSpeaking(false);
    }
  };

  // 3D mouse parallax tracking
  const handle3DMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    const el = e.currentTarget;
    const rect = el.getBoundingClientRect();
    const x = e.clientX - rect.left - rect.width / 2;
    const y = e.clientY - rect.top - rect.height / 2;
    setTilt({
      x: (x / rect.width) * 12,
      y: -(y / rect.height) * 12
    });
  };

  const resetTilt = () => {
    setTilt({ x: 0, y: 0 });
  };

  // Weather dynamic lookup
  const weatherState = DISTRICT_WEATHER_DATA[selectedDistrict] || {
    temp: 31,
    humidity: 75,
    rainfallChance: 30,
    conditionBN: "আংশিক রৌদ্রোজ্জ্বল",
    conditionEN: "Mostly Sunny",
    recommendationsBN: ["পর্যাপ্ত জল উন্নয়ন নিশ্চিত রাখুন।", "অতিরিক্ত কীটনাশক ব্যবহার এড়িয়ে চলুন।"],
    recommendationsEN: ["Keep irrigation in check.", "Avoid applying excess weedicides."]
  };

  // 1. Submit Voice Assistant Question
  const handleChatSubmit = async (queryText = chatInput) => {
    const promptValue = queryText.trim();
    if (!promptValue) return;

    const userMsg = {
      id: Date.now().toString(),
      sender: "user",
      text: promptValue,
      timestamp: new Date().toLocaleTimeString(lang === "BN" ? "bn-BD" : "en-US", { hour: "numeric", minute: "2-digit" })
    };

    setChatHistory(prev => [...prev, userMsg]);
    setChatInput("");
    setIsChatLoading(true);

    try {
      const response = await fetch("/api/farmer-assistance", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          question: promptValue,
          history: chatHistory
        })
      });

      if (!response.ok) throw new Error("Assistant response failed");

      const result = await response.json();
      const assistantMsg = {
        id: (Date.now() + 1).toString(),
        sender: "assistant",
        text: result.answer,
        timestamp: new Date().toLocaleTimeString(lang === "BN" ? "bn-BD" : "en-US", { hour: "numeric", minute: "2-digit" })
      };
      setChatHistory(prev => [...prev, assistantMsg]);
      speakText(result.answer);
    } catch (err) {
      const errorMsg = {
        id: (Date.now() + 1).toString(),
        sender: "assistant",
        text: lang === "BN" ? "দুঃখিত, সংযোগে ক্রটি হয়েছে। দয়া করে পুনরায় চেষ্টা করুন।" : "Sorry, could not connect. Please try again.",
        timestamp: "এখন"
      };
      setChatHistory(prev => [...prev, errorMsg]);
    } finally {
      setIsChatLoading(false);
    }
  };

  // Voice Speech Recognition setup for easy speech-to-text
  const toggleRecording = () => {
    if (isRecording) {
      setIsRecording(false);
      return;
    }

    if (typeof window !== "undefined") {
      const SpeechReg = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
      if (!SpeechReg) {
        alert(lang === "BN" ? "আপনার ব্রাউজার ভয়েস ইনপুট সমর্থন করে না।" : "Your browser does not support Speech Recognition.");
        return;
      }
      const recognition = new SpeechReg();
      recognition.continuous = false;
      recognition.lang = lang === "BN" ? "bn-BD" : "en-US";
      recognition.interimResults = false;

      recognition.onstart = () => {
        setIsRecording(true);
        stopSpeaking();
      };

      recognition.onresult = (event: any) => {
        const transcript = event.results[0][0].transcript;
        if (transcript) {
          setChatInput(transcript);
          handleChatSubmit(transcript);
        }
      };

      recognition.onerror = () => {
        setIsRecording(false);
      };

      recognition.onend = () => {
        setIsRecording(false);
      };

      recognition.start();
    }
  };

  // 2. Submit Soil & Crop recommendation lookup
  const runSoilRecommendation = async () => {
    setRecommendLoad(true);
    setRecommendResult(null);

    try {
      const response = await fetch("/api/recommend-crop-fertilizer", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          soilType,
          division: selectedDistrict,
          budgetStatus,
          selectedSeason: season
        })
      });

      if (!response.ok) throw new Error();
      const resultData = await response.json();
      setRecommendResult(resultData);
    } catch (err) {
      alert("ত্রুটি দেখা দিয়েছে।");
    } finally {
      setRecommendLoad(false);
    }
  };

  // 3. Submit Market Prices lookup
  const analyzeMarketPrices = async () => {
    setMarketLoading(true);
    try {
      const response = await fetch("/api/market-trends", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          crop: selectedMarketCrop,
          district: selectedDistrict
        })
      });
      if (!response.ok) throw new Error();
      const info = await response.json();
      setMarketResult(info);
    } catch (err) {
      console.error(err);
    } finally {
      setMarketLoading(false);
    }
  };

  // 4. Submit New Community Post
  const handleCreatePostSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newPostTitle || !newPostContent) return;

    const newPost: CommunityPost = {
      id: "cust-" + Date.now().toString(),
      author: currentUserRole === "expert" ? "কৃষিবিদ কায়সার মাহমুদ (Expert)" : "মোঃ আলতাব আলী (কৃষক)",
      district: selectedDistrict.split(" ")[0],
      crop: newPostCrop,
      title: newPostTitle,
      content: newPostContent,
      likes: 1,
      createdAt: new Date().toLocaleDateString(lang === "BN" ? "bn-BD" : "en-US"),
      comments: []
    };

    setCommunityPosts([newPost, ...communityPosts]);
    setNewPostTitle("");
    setNewPostContent("");
    setShowCreatePost(false);
  };

  // Local Post Comment addition helper
  const handleAddComment = (postId: string) => {
    const text = newCommentText[postId]?.trim();
    if (!text) return;

    setCommunityPosts(prevPosts =>
      prevPosts.map(post => {
        if (post.id === postId) {
          const newComment = {
            id: Date.now().toString(),
            author: currentUserRole === "expert" ? "কৃষিবিদ কায়সার মাহমুদ (Expert)" : "কৃষক সমাজ সদস্য",
            role: currentUserRole,
            content: text,
            createdAt: new Date().toLocaleDateString(lang === "BN" ? "bn-BD" : "en-US")
          };
          return {
            ...post,
            comments: [...post.comments, newComment]
          };
        }
        return post;
      })
    );

    setNewCommentText(prev => ({ ...prev, [postId]: "" }));
  };

  const handlePostLike = (postId: string) => {
    setCommunityPosts(prevPosts =>
      prevPosts.map(post => {
        if (post.id === postId) {
          return { ...post, likes: post.likes + 1 };
        }
        return post;
      })
    );
  };

  return (
    <div className="min-h-screen bg-[#041d15] text-white font-sans overflow-x-hidden pb-12 transition-all">
      {/* Visual background atmospheric blurs */}
      <div className="absolute top-0 left-0 w-full h-[600px] overflow-hidden pointer-events-none">
        <div className="absolute -top-40 -left-40 w-96 h-96 bg-emerald-500/10 rounded-full blur-[140px] animate-pulse"></div>
        <div className="absolute top-40 right-10 w-80 h-90 bg-emerald-600/10 rounded-full blur-[160px]"></div>
      </div>

      {/* Top Bar / Header */}
      <header className="max-w-7xl mx-auto px-4 pt-6 pb-4">
        <div className="bg-[#0a2e22]/90 backdrop-blur-md border border-emerald-950/40 rounded-[2rem] p-4 sm:p-6 flex flex-col md:flex-row justify-between items-center gap-4 shadow-xl">
          <div className="flex items-center gap-4">
            {/* Interactive Dynamic Leaf Logo with glow */}
            <motion.div 
              whileHover={{ scale: 1.1, rotate: 10 }}
              className="w-14 h-14 bg-emerald-550 rounded-2xl flex items-center justify-center shadow-[0_0_25px_rgba(16,185,129,0.55)] cursor-pointer"
            >
              <Spade className="w-8 h-8 text-white fill-emerald-100" />
            </motion.div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-2xl sm:text-3xl font-black text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 to-green-300 tracking-tight">
                  {lang === "BN" ? "কৃষি সহকারী" : "Krishi Shohayok"}
                </h1>
                <span className="text-[10px] bg-emerald-900/60 text-emerald-350 px-2.5 py-0.5 rounded-full font-bold uppercase border border-emerald-800">
                  v3.5 AI Pro
                </span>
              </div>
              <p className="text-xs text-emerald-500 font-semibold uppercase tracking-wider mt-0.5">
                {lang === "BN" ? "বাংলাদেশ ডিজিটাল কৃষি ইকোসিস্টেম" : "AI-Powered Smart Farmer Engine"}
              </p>
            </div>
          </div>

          {/* Quick Header Widget Panel */}
          <div className="flex flex-wrap items-center justify-center md:justify-end gap-3.5">
            {/* District Weather Quick Stat - clickable dropdown */}
            <div className="bg-[#051c14] border border-emerald-950 rounded-2xl px-4 py-2 flex items-center gap-3">
              <select
                value={selectedDistrict}
                onChange={(e) => setSelectedDistrict(e.target.value)}
                className="bg-transparent text-emerald-300 font-black focus:outline-none cursor-pointer text-sm"
              >
                {BANGLADESH_DISTRICTS.map((dist) => (
                  <option key={dist} value={dist} className="bg-[#051c14] text-white">
                    📍 {dist}
                  </option>
                ))}
              </select>
              <div className="w-px h-6 bg-emerald-950"></div>
              <div className="flex items-center gap-2 text-right">
                <CloudSun className="w-5 h-5 text-amber-500" />
                <span className="font-extrabold text-sm">{weatherState.temp}°C</span>
              </div>
            </div>

            {/* Language Switcher */}
            <button
              onClick={() => setLang(lang === "BN" ? "EN" : "BN")}
              className="px-4 py-2.5 bg-emerald-900/40 hover:bg-emerald-900/60 border border-emerald-800/40 rounded-2xl font-bold text-sm flex items-center gap-2 transition-all"
            >
              <Languages className="w-4 h-4 text-emerald-400" />
              <span>{lang === "BN" ? "English" : "বাংলা"}</span>
            </button>

            {/* Offline-First Simulate Trigger */}
            <button
              onClick={() => setOfflineMode(!offlineMode)}
              className={`px-4 py-2.5 rounded-2xl font-bold text-sm transition-all flex items-center gap-2 border ${
                offlineMode
                  ? "bg-amber-950/40 border-amber-800 text-amber-300"
                  : "bg-emerald-950/40 border-emerald-800 text-emerald-300"
              }`}
            >
              <span className={`w-2.5 h-2.5 rounded-full ${offlineMode ? "bg-amber-500 animate-pulse" : "bg-emerald-500 animate-ping"}`} />
              <span>
                {offlineMode
                  ? lang === "BN" ? "অফলাইন ক্যাশ মোড" : "Offline Caching"
                  : lang === "BN" ? "অনলাইন ক্লাউড" : "Online Mode"}
              </span>
            </button>
          </div>
        </div>
      </header>

      {/* Warning Ticker bar */}
      <AnimatePresence>
        {showNotificationAlert && (
          <div className="max-w-7xl mx-auto px-4 mt-2 mb-4">
            <motion.div
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="bg-gradient-to-r from-red-950/60 via-amber-950/30 to-emerald-950/50 backdrop-blur-md border border-red-500/20 rounded-2xl p-3 flex justify-between items-center gap-3 shadow-[0_0_15px_rgba(239,68,68,0.1)]"
            >
              <div className="flex items-center gap-3 overflow-hidden">
                <AlertOctagon className="w-5 h-5 text-red-500 animate-bounce flex-shrink-0" />
                <span className="text-xs sm:text-sm font-bold text-red-300 truncate">
                  🚨 {lang === "BN" 
                    ? "সিলেট অঞ্চলে অতিবৃষ্টি সতর্কতা! আকস্মিক পানি বৃদ্ধির সম্ভাবনা রয়েছে।" 
                    : "Heavy rain advisory in Sylhet region! Flash floods probability is high."}
                </span>
                <span className="hidden lg:inline text-xs bg-red-900/60 text-red-400 px-2 py-0.5 rounded-md font-bold uppercase tracking-widest border border-red-800">
                  Critical
                </span>
              </div>
              <button
                onClick={() => setShowNotificationAlert(false)}
                className="text-red-400 hover:text-red-300 text-xs font-black cursor-pointer bg-red-900/20 px-2.5 py-1 rounded-lg"
              >
                ✕
              </button>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Main Container - 3D styled header card with perspective */}
      <div className="max-w-7xl mx-auto px-4 mt-4 grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch">
        
        {/* Left Interactive Feature: Immersive 3D styled Banner */}
        <div 
          className="lg:col-span-8 flex flex-col justify-between"
          onMouseMove={handle3DMouseMove}
          onMouseLeave={resetTilt}
          style={{ perspective: 1000 }}
        >
          <motion.div
            animate={{
              rotateY: tilt.x,
              rotateX: tilt.y,
              scale: isHovered ? 1.01 : 1
            }}
            transition={{ type: "spring", stiffness: 220, damping: 25 }}
            onHoverStart={() => setIsHovered(true)}
            onHoverEnd={() => setIsHovered(false)}
            style={{ transformStyle: "preserve-3d" }}
            className="bg-gradient-to-br from-[#0a2e22] to-[#041a13] border-2 border-emerald-500/20 rounded-[2.5rem] p-6 sm:p-10 flex flex-col justify-between min-h-[380px] shadow-2xl relative overflow-hidden group cursor-pointer"
          >
            {/* Ambient neon orbs */}
            <div className="absolute -top-32 -right-32 w-80 h-80 bg-emerald-500/10 rounded-full blur-[80px] group-hover:scale-125 transition-all duration-700"></div>
            
            <div style={{ transform: "translateZ(50px)" }}>
              <span className="px-4 py-1.5 bg-emerald-500 text-black text-xs font-black rounded-full uppercase tracking-widest inline-block shadow-lg shadow-emerald-400/20">
                🚀 AI TECHNOLOGIES
              </span>
              <h2 className="text-3xl sm:text-5xl font-black mt-6 leading-tight mb-4 text-white">
                {lang === "BN" ? "সহজে ফসলের রোগ ও" : "Detect Crop Disease"} <br/>
                <span className="text-emerald-400">{lang === "BN" ? "সার নির্ণয় করুন" : "& Fertilizer Needs"}</span>
              </h2>
              <p className="text-emerald-350/80 text-base sm:text-lg max-w-lg leading-relaxed">
                {lang === "BN"
                  ? "আপনার ফোনের ক্যামেরা দিয়ে ধান, আলু, শাকসবজি অথবা মৎস্য খামারের ছবি তুলে আপলোড করুন। এআই সাথে সাথে নির্ভুল সমাধান দেবে।"
                  : "Snap or upload a photo of your leaves, vegetables or fish tanks. Our senior AI Extension agent models calculate diagnosis instantly."}
              </p>
            </div>

            <div style={{ transform: "translateZ(80px)" }} className="mt-8 flex flex-col sm:flex-row gap-4">
              <button
                onClick={() => setActiveTab("disease")}
                className="px-8 py-4 bg-emerald-500 hover:bg-emerald-450 text-black rounded-2xl font-black text-lg flex items-center justify-center gap-3 transition-all transform shadow-xl shadow-emerald-950"
              >
                <Camera className="w-6 h-6" />
                {lang === "BN" ? "রোগ বালাই চেক করুন" : "Open Leaf Scanner"}
              </button>
              <button
                onClick={() => setActiveTab("assistant")}
                className="px-8 py-4 border border-emerald-500/30 text-emerald-300 rounded-2xl font-black text-lg flex items-center justify-center gap-3 bg-emerald-500/5 hover:bg-emerald-500/15 transition-all"
              >
                🎙️ {lang === "BN" ? "ভয়েস সহকারী" : "Bangla Voice Assistant"}
              </button>
            </div>

            <div className="absolute bottom-8 right-8 hidden sm:block">
              <div className="flex items-center gap-2.5 text-emerald-600 font-mono text-xs tracking-widest font-black">
                <span>ONLINE_FARMER_ECO_CORE</span>
                <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse"></span>
              </div>
            </div>
          </motion.div>
        </div>

        {/* Right Side: High fidelity mini widgets */}
        <div className="lg:col-span-4 flex flex-col gap-6">
          
          {/* Audio Synthesizer Status panel */}
          <div className="bg-[#0b2416] border border-emerald-900/30 rounded-[2rem] p-5 flex flex-col justify-between flex-1 relative overflow-hidden">
            <div className="flex justify-between items-start mb-4">
              <div>
                <span className="text-emerald-500 font-bold uppercase text-[10px] tracking-widest">
                  {lang === "BN" ? "বাংলা ভয়েস রিডার" : "BANGLA AUDIO SYNTH"}
                </span>
                <h3 className="font-extrabold text-white text-base mt-0.5">
                  {lang === "BN" ? "কথা বলা সহকারী সচল" : "Speak response active"}
                </h3>
              </div>
              <button
                onClick={() => setVoiceSynthesizerActive(!voiceSynthesizerActive)}
                className={`p-2.5 rounded-xl border transition-all ${
                  voiceSynthesizerActive
                    ? "bg-emerald-500 border-emerald-400 text-black shadow-md"
                    : "bg-zinc-800 border-zinc-700 text-zinc-400"
                }`}
              >
                {voiceSynthesizerActive ? <Volume2 className="w-5 h-5" /> : <VolumeX className="w-5 h-5" />}
              </button>
            </div>

            <div className="bg-black/30 p-3 rounded-xl border border-emerald-950/60 mb-2">
              <p className="text-xs text-emerald-300 italic line-clamp-3">
                {lang === "BN"
                  ? '"ধানের পাতায় যেকোনো বাদামী দাগ বা ব্যাকটেরিয়াল ছত্রাক দূর করার উপায় জানতে রোগ বালাই ট্যাবে ছবি দিন।"'
                  : '"For analyzing crop blast, use the leaf scanner or record voice questions directly."'}
              </p>
            </div>

            <div className="flex items-center gap-2 mt-2">
              <span className="text-[10px] bg-emerald-900/40 text-emerald-400 px-2 py-0.5 rounded font-black">
                TTS Reader
              </span>
              <span className="text-[10px] text-zinc-400 font-bold">
                {lang === "BN" ? "ভয়েস স্পিকার সক্রিয় আছে" : "Reading voice ready"}
              </span>
            </div>
            {isSpeaking && (
              <div className="absolute bottom-4 right-4 flex items-center gap-1">
                <span className="w-1.5 h-4 bg-emerald-500 animate-bounce"></span>
                <span className="w-1.5 h-6 bg-emerald-400 animate-bounce delay-75"></span>
                <span className="w-1.5 h-3 bg-emerald-500 animate-bounce delay-150"></span>
              </div>
            )}
          </div>

          {/* Quick Stats on Fertilizer Prices & Seed Stock */}
          <div className="bg-[#0f1f1a] border border-emerald-950/60 rounded-[2rem] p-5 flex flex-col justify-between flex-1">
            <div className="flex justify-between items-center mb-3">
              <h3 className="text-emerald-500 font-bold uppercase text-[10px] tracking-widest">
                {lang === "BN" ? "আজকের সারের বাজার দর" : "Todays Fertilizer Rates"}
              </h3>
              <span className="text-[10px] text-zinc-400 font-bold">
                টিএসপি / ইউরিয়া
              </span>
            </div>
            <div className="space-y-2 text-sm">
              <div className="flex justify-between items-center bg-black/20 p-2.5 rounded-lg border border-emerald-950">
                <span className="text-zinc-350">{lang === "BN" ? "ইউরিয়া (Urea)" : "Urea"}</span>
                <span className="font-extrabold text-emerald-300">৳২৭ / কেজি</span>
              </div>
              <div className="flex justify-between items-center bg-black/20 p-2.5 rounded-lg border border-emerald-950">
                <span className="text-zinc-350">{lang === "BN" ? "টিএসপি (TSP)" : "TSP"}</span>
                <span className="font-extrabold text-emerald-300">৳২৮ / কেজি</span>
              </div>
              <div className="flex justify-between items-center bg-black/20 p-2.5 rounded-lg border border-emerald-950">
                <span className="text-zinc-350">{lang === "BN" ? "এমওপি (MOP)" : "MOP"}</span>
                <span className="font-extrabold text-emerald-300">৳২০ / কেজি</span>
              </div>
            </div>
          </div>

        </div>
      </div>

      {/* Main Tab Navigation Buttons for Lower Section */}
      <section className="max-w-7xl mx-auto px-4 mt-8">
        <div className="bg-[#0a2e22]/80 border border-emerald-950/60 rounded-[2rem] p-3 flex flex-wrap gap-2 shadow-inner">
          {[
            { id: "disease", labelBN: "🔬 রোগ বালাই", labelEN: "🔬 Plant Disease" },
            { id: "weather", labelBN: "☁️ আবহাওয়া সতর্ক", labelEN: "☁️ Weather Radar" },
            { id: "soil", labelBN: "🌱 সার ও ফসল", labelEN: "🌱 Crop Advising" },
            { id: "prices", labelBN: "📈 বাজার বিশ্লেষণ", labelEN: "📈 Market System" },
            { id: "assistant", labelBN: "🎙️ এআই আলাপন", labelEN: "🎙️ Voice Q&A" },
            { id: "community", labelBN: "👥 মতামত আদান-প্রদান", labelEN: "👥 Farmer Community" }
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => {
                setActiveTab(tab.id as any);
                stopSpeaking();
              }}
              className={`flex-1 min-w-[140px] py-4 px-3 rounded-2xl font-black text-center text-sm. sm:text-base cursor-pointer border transition-all ${
                activeTab === tab.id
                  ? "bg-emerald-550 border-emerald-400 text-white shadow-xl shadow-emerald-900"
                  : "bg-[#051a13] border-emerald-950 text-emerald-200/80 hover:bg-[#07241a] hover:text-white"
              }`}
            >
              {lang === "BN" ? tab.labelBN : tab.labelEN}
            </button>
          ))}
        </div>
      </section>

      {/* Dynamic Tab Panel Content */}
      <main className="max-w-7xl mx-auto px-4 mt-6">
        <AnimatePresence mode="wait">
          <motion.div
            key={activeTab}
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -15 }}
            transition={{ duration: 0.25 }}
          >
            
            {/* 1. PLANT DISEASE DETECTION TAB */}
            {activeTab === "disease" && (
              <div className="space-y-4">
                <div className="bg-emerald-950/20 border border-emerald-800/30 p-5 rounded-3xl mb-4">
                  <h3 className="text-xl font-bold flex items-center gap-2">
                    <CheckCircle className="w-5 h-5 text-emerald-400" />
                    {lang === "BN" ? "মোবাইল ক্যামেরা ও ইমেজ বিশ্লেষণ" : "Mobile Camera & Crop Scanning"}
                  </h3>
                  <p className="text-zinc-300 text-xs sm:text-sm mt-1.5 leading-relaxed">
                    {lang === "BN"
                      ? "আপনার ফসলের ছবি এখানে আপলোড করুন। কৃত্রিম বুদ্ধিমত্তা চালিত ডিটেক্টর নিমজ্জিত ২ডি/৩ডি প্রজেকশন তৈরি করে ধানের ব্লাস্ট রোগ, আলুর মরক রোগ, গমের ড্যাম্পিং অফসহ জটিল রোগ বালাই চিহ্নিত করবে এবং উপযুক্ত সমাধান জানাবে।"
                      : "Perform leaf scanner diagnostic testing. Instantly identify potato late blight, paddy blast, mango anthracnose, wheat streak, and receive specialized chemical & organic spray dosage schedules."}
                  </p>
                </div>
                <DiseaseDetector lang={lang} />
              </div>
            )}

            {/* 2. WEATHER ADVISORY & WARNINGS TAB */}
            {activeTab === "weather" && (
              <div className="bg-white dark:bg-zinc-900 text-zinc-950 dark:text-white border border-emerald-100 dark:border-zinc-800 rounded-[2.5rem] p-6 sm:p-8 space-y-6 shadow-xl">
                <div className="flex flex-col sm:flex-row justify-between items-start gap-4">
                  <div>
                    <span className="text-emerald-600 font-extrabold uppercase text-xs tracking-wider">
                      {lang === "BN" ? "স্মার্ট আবহাওয়া পূর্বাভাস" : "SMART WEATHER RADAR"}
                    </span>
                    <h2 className="text-3xl font-black mt-1 text-zinc-900 dark:text-white">
                      {selectedDistrict} {lang === "BN" ? "জেলা আবহাওয়া তথ্য" : "District Insights"}
                    </h2>
                    <p className="text-zinc-500 text-sm">
                      {lang === "BN" ? "রিয়েল-টাইম আবহাওয়া সতর্কবার্তা এবং কৃষকদের করণীয় বার্তা" : "Live prediction, hazard levels & tailored agricultural suggestions."}
                    </p>
                  </div>

                  <div className="p-4 bg-emerald-50 dark:bg-zinc-800 rounded-3xl text-center min-w-[150px]">
                    <span className="text-zinc-400 text-xs font-bold uppercase">{lang === "BN" ? "তাপমাত্রা" : "Temperature"}</span>
                    <p className="text-4xl font-extrabold text-emerald-600 dark:text-emerald-450 mt-1">{weatherState.temp}°C</p>
                    <span className="text-zinc-500 font-bold text-xs">
                      {lang === "BN" ? weatherState.conditionBN : weatherState.conditionEN}
                    </span>
                  </div>
                </div>

                {/* Weather Warning Cards if exists */}
                {weatherState.warning ? (
                  <div className="bg-red-50 dark:bg-red-950/20 border-2 border-red-500/35 rounded-3xl p-5 flex flex-col sm:flex-row items-center gap-4 text-red-900 dark:text-red-300">
                    <AlertOctagon className="w-12 h-12 text-red-500 flex-shrink-0 animate-pulse" />
                    <div>
                      <h4 className="font-black text-lg">
                        ⚠️ {lang === "BN" ? weatherState.warning.titleBN : weatherState.warning.titleEN}
                        <span className="ml-2 py-0.5 px-2.5 bg-red-600 text-white text-[10px] rounded-full uppercase font-black">
                          {weatherState.warning.severity}
                        </span>
                      </h4>
                      <p className="text-sm mt-1.5 leading-relaxed text-zinc-800 dark:text-zinc-350">
                        {lang === "BN" ? weatherState.warning.messageBN : weatherState.warning.messageEN}
                      </p>
                    </div>
                  </div>
                ) : (
                  <div className="bg-emerald-50 dark:bg-emerald-950/10 border border-emerald-150 dark:border-emerald-950 rounded-3xl p-5 flex items-center gap-4 text-emerald-800 dark:text-emerald-300">
                     <CheckCircle className="w-10 h-10 text-emerald-500 flex-shrink-0" />
                     <div>
                       <h4 className="font-extrabold text-base">
                         {lang === "BN" ? "সাধারণ সতর্কতা: স্বাভাবিক আবহাওয়া" : "No Critical Weather Hazard Level"}
                       </h4>
                       <p className="text-sm">
                         {lang === "BN" ? "বর্তমানে কোনো মারাত্মক বন্যা, ঝড় বা ঘূর্ণিঝড়ের পূর্বাভাস নেই।" : "Everything stable. Continue standard organic soil mulching & daily routines."}
                       </p>
                     </div>
                  </div>
                )}

                {/* Weather Stats Grid */}
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                  <div className="bg-zinc-50 dark:bg-zinc-800/40 p-5 rounded-2xl border text-center">
                    <span className="text-zinc-400 text-xs font-bold">{lang === "BN" ? "বাতাসের আর্দ্রতা" : "Humidity"}</span>
                    <p className="text-2xl font-black mt-2 text-zinc-800 dark:text-emerald-300">{weatherState.humidity}%</p>
                  </div>
                  <div className="bg-zinc-50 dark:bg-zinc-800/40 p-5 rounded-2xl border text-center">
                    <span className="text-zinc-400 text-xs font-bold">{lang === "BN" ? "বৃষ্টিপাতের সম্ভাবনা" : "Precipitation"}</span>
                    <p className="text-2xl font-black mt-2 text-zinc-800 dark:text-emerald-300">{weatherState.rainfallChance}%</p>
                  </div>
                  <div className="bg-zinc-50 dark:bg-zinc-800/40 p-5 rounded-2xl border text-center">
                    <span className="text-zinc-400 text-xs font-bold">{lang === "BN" ? "উদ্ভিদের জন্য ঝুকি" : "Crop Stress Level"}</span>
                    <p className="text-2xl font-black mt-2 text-zinc-800 dark:text-emerald-300">
                      {weatherState.rainfallChance > 60 ? (lang === "BN" ? "মাঝারি" : "Medium") : (lang === "BN" ? "কম" : "Low")}
                    </p>
                  </div>
                </div>

                {/* Specific Farmer Recommendations */}
                <div className="bg-[#fadcb9]/20 dark:bg-amber-950/10 border border-[#f5c68b]/30 dark:border-amber-900/10 p-6 rounded-3xl space-y-4">
                  <h3 className="font-black text-amber-900 dark:text-amber-400 flex items-center gap-2">
                    🌾 {lang === "BN" ? "আবহাওয়া ভিত্তিক কৃষি পরামর্শ" : "Weather and Crop Actions"}
                  </h3>
                  <ul className="space-y-2">
                    {(lang === "BN" ? weatherState.recommendationsBN : weatherState.recommendationsEN).map((rec, idx) => (
                      <li key={idx} className="text-sm flex items-start gap-2.5 leading-relaxed text-zinc-700 dark:text-zinc-300">
                        <span className="text-amber-600 mt-1">●</span>
                        <span>{rec}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            )}

            {/* 3. FERTILIZER & CROP RECOMMENDATION */}
            {activeTab === "soil" && (
              <div className="bg-white dark:bg-zinc-900 border border-emerald-100 dark:border-zinc-800 rounded-[2.5rem] p-6 sm:p-8 space-y-6 shadow-xl">
                <div>
                  <span className="text-emerald-600 font-extrabold uppercase text-xs tracking-wider">
                    {lang === "BN" ? "মাটি পরীক্ষা ও সার নির্ধারণ" : "SOIL ANALYSIS & SUGGESTIONS"}
                  </span>
                  <h2 className="text-3xl font-black text-zinc-900 dark:text-white mt-1">
                    {lang === "BN" ? "স্মার্ট সার ও ফসল পরামর্শক" : "Fertilizer & Seasonal Crop Assistant"}
                  </h2>
                  <p className="text-zinc-500 text-sm">
                    {lang === "BN" ? "আপনার জমির মাটি ও বাজেটের সাথে সামঞ্জস্যপূর্ণ ফসলের জাত ও সারের পরিমাণ জেনে নিন।" : "Suggests highly optimized crops, urea, TSP, potash levels, and cost saving strategies."}
                  </p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 bg-zinc-50 dark:bg-zinc-800/20 p-5 rounded-3xl border border-zinc-200 dark:border-zinc-800">
                  {/* Select Soil Type */}
                  <div className="space-y-1.5">
                    <label className="text-zinc-650 dark:text-zinc-300 text-xs font-black uppercase">
                      🗺️ {lang === "BN" ? "মাটির ধরন" : "Soil Type"}
                    </label>
                    <select
                      value={soilType}
                      onChange={(e) => setSoilType(e.target.value)}
                      className="w-full bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 p-3 rounded-2xl font-bold font-sm text-zinc-800 dark:text-white"
                    >
                      <option value="loamy">{lang === "BN" ? "দোয়াশ মাটি" : "Loamy Soil"}</option>
                      <option value="clayey">{lang === "BN" ? "এঁটেল মাটি" : "Clayey Soil"}</option>
                      <option value="sandy">{lang === "BN" ? "বেলে মাটি" : "Sandy Soil"}</option>
                      <option value="silty">{lang === "BN" ? "পলি বিশিষ্ট মাটি" : "Silty Clay"}</option>
                    </select>
                  </div>

                  {/* Select Budget Type */}
                  <div className="space-y-1.5">
                    <label className="text-zinc-650 dark:text-zinc-300 text-xs font-black uppercase">
                      💰 {lang === "BN" ? "বাজেট ক্যাটাগরি" : "Budget Target"}
                    </label>
                    <select
                      value={budgetStatus}
                      onChange={(e) => setBudgetStatus(e.target.value)}
                      className="w-full bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 p-3 rounded-2xl font-bold font-sm text-zinc-800 dark:text-white"
                    >
                      <option value="Low Budget">{lang === "BN" ? "সীমিত খরচ (ছোট খামার)" : "Low Budget (Marginal Farmer)"}</option>
                      <option value="Medium">{lang === "BN" ? "মাঝারি বাজেট" : "Standard Budget"}</option>
                      <option value="Advanced">{lang === "BN" ? "সর্বোচ্চ উৎপাদন পদ্ধতি" : "Advanced/Intense Farming"}</option>
                    </select>
                  </div>

                  {/* Select Season */}
                  <div className="space-y-1.5">
                    <label className="text-zinc-650 dark:text-zinc-300 text-xs font-black uppercase">
                      🍂 {lang === "BN" ? "বর্তমান ঋতু / মরশুম" : "Agricultural Season"}
                    </label>
                    <select
                      value={season}
                      onChange={(e) => setSeason(e.target.value)}
                      className="w-full bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 p-3 rounded-2xl font-bold font-sm text-zinc-800 dark:text-white"
                    >
                      <option value="Kharif-1">{lang === "BN" ? "খরিফ-১ (মার্চ - জুন)" : "Kharif-1 (March - June)"}</option>
                      <option value="Kharif-2">{lang === "BN" ? "খরিফ-২ (জুলাই - অক্টোবর)" : "Kharif-2 (July - October)"}</option>
                      <option value="Rabi">{lang === "BN" ? "রবি মরশুম (নভেম্বর - ফেব্রুয়ারি)" : "Rabi (Winter Season)"}</option>
                    </select>
                  </div>
                </div>

                <button
                  onClick={runSoilRecommendation}
                  disabled={recommendLoad}
                  className="w-full py-4.5 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white font-black text-lg rounded-2xl transition-all shadow-md flex items-center justify-center gap-2"
                >
                  {recommendLoad ? (
                    <>
                      <Sparkles className="w-5 h-5 animate-spin" />
                      <span>{lang === "BN" ? "এআই পরামর্শ তৈরি করছে..." : "AI Calculating Soil Plan..."}</span>
                    </>
                  ) : (
                    <>
                      <Sparkles className="w-5 h-5" />
                      <span>{lang === "BN" ? "এআই পরামর্শ ও সার তালিকা দেখান" : "Generate Custom Soil & Fertilizer Blueprint"}</span>
                    </>
                  )}
                </button>

                {recommendResult && (
                  <div className="grid grid-cols-1 md:grid-cols-12 gap-6 mt-4">
                    
                    {/* Cultivation crops recommendation */}
                    <div className="md:col-span-5 bg-emerald-50/50 dark:bg-emerald-950/10 p-6 rounded-3xl border border-emerald-100/60 dark:border-emerald-900/10 space-y-4">
                      <h4 className="font-extrabold text-[#0d3420] dark:text-emerald-450 text-base border-b pb-2">
                        🌾 {lang === "BN" ? "প্রস্তাবিত লাভজনক ফসল" : "Recommended Seasonal Crops"}
                      </h4>
                      <div className="space-y-4">
                        {recommendResult.recommendedCrops.map((crop: any, index: number) => (
                          <div key={index} className="bg-white dark:bg-zinc-900/80 p-3 rounded-xl shadow-xs">
                            <span className="font-black text-[#15462c] dark:text-emerald-300 text-sm">
                              {crop.cropName}
                            </span>
                            <div className="flex justify-between items-center text-xs text-zinc-500 dark:text-zinc-450 mt-1">
                              <span>{lang === "BN" ? "উপযোগিতা:" : "Suitability:"} <strong className="text-emerald-600 font-extrabold">{crop.suitability}</strong></span>
                              <span>{lang === "BN" ? "জীবনকাল:" : "Duration:"} {crop.farmingDuration}</span>
                            </div>
                            <p className="text-[11px] text-[#cca51e] font-extrabold mt-1">
                              {lang === "BN" ? "প্রত্যাশিত ফলন:" : "Yield:"} {crop.expectedYield}
                            </p>
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* Sizing routine */}
                    <div className="md:col-span-7 space-y-4">
                      <div className="bg-zinc-50 dark:bg-zinc-800/40 p-5 rounded-3xl border">
                        <h4 className="font-extrabold text-zinc-800 dark:text-white text-sm mb-3">
                          🧪 {lang === "BN" ? "সুষম সার প্রয়োগের অনুপাত (প্রতি শতকে)" : "Fertilizer Routine (Per Decimal of Soil)"}
                        </h4>
                        <div className="space-y-2">
                          {recommendResult.fertilizerRoutine.map((item: any, idx: number) => (
                            <div key={idx} className="flex justify-between items-start border-b dark:border-zinc-800 pb-2 text-xs">
                              <div>
                                <span className="font-black text-zinc-700 dark:text-zinc-200">{item.name}</span>
                                <p className="text-zinc-400 text-[10px] mt-0.5">{item.timing}</p>
                              </div>
                              <span className="font-black text-emerald-600 bg-emerald-50 dark:bg-zinc-800 px-2 py-1 rounded-lg">
                                {item.amount}
                              </span>
                            </div>
                          ))}
                        </div>
                      </div>

                      {/* Cost Optimization tips */}
                      <div className="bg-amber-50/55 dark:bg-amber-950/10 p-5 rounded-3xl border border-amber-100 dark:border-amber-950/30">
                        <h4 className="font-extrabold text-[#744510] dark:text-amber-400 text-sm mb-2 flex items-center gap-1.5">
                          💰 {lang === "BN" ? "ক্ষুদ্র কৃষকদের জন্য খরচ সাশ্রয় টিপস" : "Small Farmer Cost Saving Tips"}
                        </h4>
                        <ul className="space-y-1.5 list-disc list-inside text-xs text-[#523d14] dark:text-zinc-350 leading-relaxed">
                          {recommendResult.costOptimizationTips.map((tip: string, idx: number) => (
                            <li key={idx}>{tip}</li>
                          ))}
                        </ul>
                      </div>
                    </div>

                  </div>
                )}
              </div>
            )}

            {/* 4. LIVE MARKET PRICES SYSTEM */}
            {activeTab === "prices" && (
              <div className="bg-white dark:bg-zinc-900 border border-emerald-100 dark:border-zinc-800 rounded-[2.5rem] p-6 sm:p-8 space-y-6 shadow-xl text-zinc-900 dark:text-white">
                <div className="flex flex-col md:flex-row justify-between items-start gap-4">
                  <div>
                    <span className="text-emerald-600 font-extrabold uppercase text-xs tracking-wider">
                      {lang === "BN" ? "দৈনিক স্থানীয় বাজার দর" : "DAILY CROP MARKET PRICING"}
                    </span>
                    <h2 className="text-3xl font-black mt-1">
                      {lang === "BN" ? "লাইভ বাজার দর ও পূর্বাভাস" : "Live Markets & Price Prediction"}
                    </h2>
                    <p className="text-zinc-505 text-sm">
                      {lang === "BN" ? "বাংলাদেশ কৃষি বিপণন অধিদপ্তর ও স্থানীয় আড়তের সর্বশেষ পাইকারি বাজার দর জানুন।" : "Real-time rates from regional arat and strategic AI marketing insights."}
                    </p>
                  </div>

                  <div className="w-full md:w-auto">
                    <label className="text-zinc-400 text-xs font-bold block mb-1">{lang === "BN" ? "ফসল সিলেক্ট" : "Select Target Crop"}</label>
                    <select
                      value={selectedMarketCrop}
                      onChange={(e) => setSelectedMarketCrop(e.target.value)}
                      className="bg-zinc-100 dark:bg-zinc-850 border p-3 rounded-2xl w-full md:w-[220px] font-bold"
                    >
                      <option value="rice">{lang === "BN" ? "চাল (Rice)" : "Rice"}</option>
                      <option value="potato">{lang === "BN" ? "গোল আলু (Potato)" : "Potato"}</option>
                      <option value="jute">{lang === "BN" ? "পাট (Jute fiber)" : "Jute fiber"}</option>
                      <option value="mango">{lang === "BN" ? "হিমসাগর আম (Mango)" : "Mango Himsagar"}</option>
                      <option value="fish">{lang === "BN" ? "রুই মাছ (Rui Fish)" : "Rui Fish"}</option>
                    </select>
                  </div>
                </div>

                {/* Main Price Analysis Panel with Sparkline */}
                {marketLoading ? (
                  <div className="h-60 flex flex-col items-center justify-center gap-2">
                    <div className="w-8 h-8 rounded-full border-4 border-emerald-600 border-t-transparent animate-spin" />
                    <span>{lang === "BN" ? "বাজার বিশ্লেষণ লোড হচ্ছে..." : "Loading market index..."}</span>
                  </div>
                ) : marketResult ? (
                  <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
                    
                    {/* Crop pricing status widget */}
                    <div className="lg:col-span-5 bg-zinc-50 dark:bg-zinc-800/40 p-6 rounded-3xl space-y-4 border order-first">
                      <div className="flex justify-between items-center text-xs text-zinc-400">
                        <span>{lang === "BN" ? "সবচেয়ে নির্ভরযোগ্য গড় দর" : "Approx. Local Average"}</span>
                        <span className="font-black text-emerald-600 uppercase tracking-wider">
                          Trend: {marketResult.trendDirection === "UP" ? "📈 " + (lang === "BN" ? "উর্ধ্বমুখী" : "Rising") : "📉 " + (lang === "BN" ? "নিম্নমুখী" : "Declining")}
                        </span>
                      </div>
                      
                      <div className="space-y-1">
                        <span className="text-zinc-405 text-xs font-bold">{lang === "BN" ? "আজকের পাইকারি দর:" : "Today Market:"}</span>
                        <p className="text-3xl font-black text-emerald-600">{marketResult.currentPrice}</p>
                      </div>

                      <div className="flex justify-between text-xs pt-2 border-t dark:border-zinc-800">
                        <span>{lang === "BN" ? "গত সপ্তাহের দাম:" : "Last Week Rate:"} {marketResult.lastWeekPrice}</span>
                        <span className="font-black text-[#caa51e]">{lang === "BN" ? "আগামী ৪ সপ্তাহের এআই পূর্বাভাস:" : "AI Target Month:"} {marketResult.predictedNextMonthPrice}</span>
                      </div>

                      {/* Visual SVG mini spark chart */}
                      <div className="pt-2">
                        <span className="text-[10px] text-zinc-400 font-bold block mb-2">{lang === "BN" ? "বিগত ৭ দিনের মূল্যগ্রাফ" : "Last 7 Days Trendline"}</span>
                        <svg viewBox="0 0 100 30" className="w-full h-12 stroke-emerald-500 fill-none" strokeWidth="2.5">
                          <path d="M0,25 Q15,10 30,22 T60,5 T90,15 T100,2" />
                        </svg>
                      </div>
                    </div>

                    {/* Nearby Selling marketplaces List */}
                    <div className="lg:col-span-7 space-y-4">
                      
                      {/* Expert selling strategy comments */}
                      <div className="bg-emerald-55/60 dark:bg-emerald-950/10 border border-emerald-150 dark:border-emerald-900/10 p-5 rounded-3xl space-y-2">
                        <h4 className="font-extrabold text-[#113a23] dark:text-emerald-400 text-sm flex items-center gap-1.5">
                          💡 {lang === "BN" ? "ক্ষুদ্র কৃষকদের আর্থিক লাভ বাড়াতে এআই কৌশল" : "AI Competitive Marketing Tips"}
                        </h4>
                        <p className="text-xs sm:text-sm text-zinc-750 dark:text-zinc-300 leading-relaxed">
                          {marketResult.aiAnalysis}
                        </p>
                      </div>

                      {/* Selling point tables based on distances */}
                      <div className="bg-zinc-50 dark:bg-zinc-800/20 rounded-2xl p-4 border max-h-[160px] overflow-y-auto">
                        <span className="text-[10px] text-zinc-400 font-bold uppercase tracking-wider block mb-2">
                          📍 {lang === "BN" ? "আপনার নিকটস্থ সেরা বিক্রয়কেন্দ্র সমুহ" : "Optimal Nearby Arat / Buying Points"}
                        </span>
                        <div className="space-y-2">
                          {marketResult.districtMarketNames.map((market: any, idx: number) => (
                            <div key={idx} className="flex justify-between items-center text-xs bg-white dark:bg-zinc-900 p-2.5 rounded-xl">
                              <div>
                                <span className="font-black">{market.market}</span>
                                <span className="text-zinc-400 block text-[10px]">{market.distance}</span>
                              </div>
                              <span className="font-black text-emerald-600">{market.price}</span>
                            </div>
                          ))}
                        </div>
                      </div>

                    </div>

                  </div>
                ) : null}
              </div>
            )}

            {/* 5. BANGLA VOICE AI ASSISTANT TAB */}
            {activeTab === "assistant" && (
              <div className="bg-white dark:bg-zinc-900 border border-emerald-100 dark:border-zinc-800 rounded-[2.5rem] p-6 sm:p-8 space-y-6 shadow-xl text-zinc-900 dark:text-white">
                <div className="flex flex-col sm:flex-row justify-between items-start gap-4">
                  <div>
                    <span className="text-emerald-600 font-extrabold uppercase text-xs tracking-wider">
                      {lang === "BN" ? "কৃষি ভয়েস ও চ্যাট রোবট" : "BANGLA VOICE CHATBOT CONVERSATION"}
                    </span>
                    <h2 className="text-3xl font-black mt-1 flex items-center gap-2">
                      🗣️ {lang === "BN" ? "মাটি ও মানুষ এআই আলাপন" : "AI Extension Specialist Chat"}
                    </h2>
                    <p className="text-zinc-505 text-sm">
                      {lang === "BN" ? "মুখে সরাসরি বাংলা বলুন বা টেক্সট লিখে কৃষি বিষয়ক যেকোনো তথ্য ও সমস্যার তাত্ক্ষণিক সমাধান চান।" : "Talk naturally in Bengali/English. Features high precision regional advice outputs."}
                    </p>
                  </div>

                  <div className="flex items-center gap-2 text-xs font-bold text-zinc-400">
                    <span className="w-2.5 h-2.5 bg-emerald-500 rounded-full animate-ping" />
                    <span>Gemini AI Engine Live</span>
                  </div>
                </div>

                {/* Dialogue Screen Frame */}
                <div className="bg-zinc-50 dark:bg-zinc-950/60 rounded-3xl border p-4 sm:p-6 flex flex-col justify-between min-h-[380px] max-h-[500px]">
                  
                  {/* Message history */}
                  <div className="space-y-3.5 overflow-y-auto pr-2 flex-grow mb-4">
                    {chatHistory.map((msg) => (
                      <div
                        key={msg.id}
                        className={`flex gap-3.5 text-xs sm:text-sm ${
                          msg.sender === "user" ? "justify-end" : "justify-start"
                        }`}
                      >
                        {msg.sender !== "user" && (
                          <div className="w-9 h-9 rounded-full bg-emerald-700 text-white flex items-center justify-center font-black flex-shrink-0">
                            🤖
                          </div>
                        )}
                        <div
                          className={`p-3.5 rounded-2xl max-w-[80%] leading-relaxed ${
                            msg.sender === "user"
                              ? "bg-emerald-600 text-white rounded-br-none font-bold"
                              : "bg-white dark:bg-zinc-900 border border-emerald-100 dark:border-zinc-850 rounded-bl-none text-zinc-800 dark:text-zinc-200"
                          }`}
                        >
                          <p>{msg.text}</p>
                          <div className="text-[9px] text-right mt-1.5 opacity-60 font-medium">
                            {msg.timestamp}
                          </div>
                        </div>
                      </div>
                    ))}

                    {isChatLoading && (
                      <div className="flex gap-3.5 justify-start">
                        <div className="w-9 h-9 rounded-full bg-emerald-700 text-white flex items-center justify-center font-black flex-shrink-0">
                          🤖
                        </div>
                        <div className="p-3.5 bg-zinc-200/50 dark:bg-zinc-900 rounded-2xl rounded-bl-none text-xs flex gap-1.5 items-center">
                          <span className="w-1.5 h-1.5 bg-zinc-450 dark:bg-zinc-500 rounded-full animate-bounce"></span>
                          <span className="w-1.5 h-1.5 bg-zinc-450 dark:bg-zinc-500 rounded-full animate-bounce delay-75"></span>
                          <span className="w-1.5 h-1.5 bg-zinc-450 dark:bg-zinc-500 rounded-full animate-bounce delay-150"></span>
                        </div>
                      </div>
                    )}
                  </div>

                  {/* Micro speaker read controls */}
                  <div className="flex items-center justify-between border-t border-zinc-150 dark:border-zinc-800 pt-3 mb-2 text-xs">
                    <span className="text-zinc-400">
                      {isSpeaking ? (
                        <span className="text-emerald-600 font-extrabold flex items-center gap-1">
                          🔊 {lang === "BN" ? "পরামর্শ পড়ে শোনানো হচ্ছে..." : "Speaking response aloud..."}
                        </span>
                      ) : (
                        lang === "BN" ? "পরামর্শ শোনার জন্য ভয়েস অন রাখুন।" : "Click audio to speak aloud."
                      )}
                    </span>
                    {isSpeaking && (
                      <button
                        onClick={stopSpeaking}
                        className="text-red-500 font-extrabold hover:underline"
                      >
                        {lang === "BN" ? "বন্ধ করুন" : "Stop Speech"}
                      </button>
                    )}
                  </div>

                  {/* Talk Controls Bar - Circular voice pulsing visual + Field */}
                  <div className="flex items-center gap-3 bg-white dark:bg-zinc-900 border p-2.5 rounded-2xl shadow-inner">
                    <input
                      type="text"
                      value={chatInput}
                      onChange={(e) => setChatInput(e.target.value)}
                      onKeyDown={(e) => e.key === "Enter" && handleChatSubmit()}
                      placeholder={
                        lang === "BN"
                          ? "এখানে লিখুন অথবা ডান পাশের মাইকে ক্লিক করে কথা বলুন..."
                          : "Type here or tap microphone to speak..."
                      }
                      className="flex-grow bg-transparent focus:outline-none p-2 text-sm text-zinc-900 dark:text-white font-bold"
                    />

                    {/* Microphone Action with Pulsing Live Waveform */}
                    <button
                      onClick={toggleRecording}
                      className={`w-12 h-12 rounded-full flex items-center justify-center transition-all ${
                        isRecording
                          ? "bg-red-500 text-white animate-pulse shadow-lg shadow-red-200"
                          : "bg-emerald-555 hover:bg-emerald-600 text-white shadow-lg shadow-emerald-100 dark:shadow-none"
                      }`}
                    >
                      {isRecording ? <MicOff className="w-5 h-5" /> : <Mic className="w-5 h-5 text-white" />}
                    </button>

                    <button
                      onClick={() => handleChatSubmit()}
                      className="w-11 h-11 bg-zinc-100 dark:bg-zinc-800 hover:bg-emerald-50 text-zinc-650 dark:text-zinc-200 rounded-xl flex items-center justify-center transition-all border"
                    >
                      <Send className="w-4 h-4" />
                    </button>
                  </div>

                  {isRecording && (
                    <div className="mt-3 bg-red-50/70 p-3 rounded-xl border border-red-220 text-center text-xs text-red-700 font-extrabold flex items-center justify-center gap-2">
                      <span className="w-2.5 h-2.5 rounded-full bg-red-650 animate-ping" />
                      <span>{lang === "BN" ? "আপনার কথা শোনা হচ্ছে... দয়া করে প্রশ্নটি মুখে বলুন" : "Listening to your voice inputs... Ask agricultural problems now."}</span>
                    </div>
                  )}

                </div>
              </div>
            )}

            {/* 6. FARMER COMMUNITY SECTION */}
            {activeTab === "community" && (
              <div className="bg-white dark:bg-zinc-900 border border-emerald-100 dark:border-zinc-800 rounded-[2.5rem] p-6 sm:p-8 space-y-6 shadow-xl text-zinc-900 dark:text-white">
                <div className="flex flex-col sm:flex-row justify-between items-start gap-4">
                  <div>
                    <span className="text-emerald-600 font-extrabold uppercase text-xs tracking-wider">
                      {lang === "BN" ? "কৃষক অধিকার ও উন্মুক্ত ফোরাম" : "FARMERS DIGITAL PLATFORM"}
                    </span>
                    <h2 className="text-3xl font-black mt-1">
                      {lang === "BN" ? "কৃষক সমাজ ও বিশেষজ্ঞ বার্তা" : "Farmer Community & Expert Help"}
                    </h2>
                    <p className="text-zinc-505 text-sm">
                      {lang === "BN" ? "আপনার ফসল সমস্যা বা মাঠের পরিস্থিতি শেয়ার করুন, অভিজ্ঞ কর্মকর্তা ও কৃষকেরা উত্তর দেবেন।" : "Share field problems, check crop pictures and comments. Connect with registered Agro officers."}
                    </p>
                  </div>

                  <div className="flex items-center gap-3 bg-zinc-105 p-1 px-1.5 rounded-2xl border">
                    <button
                      onClick={() => setCurrentUserRole("farmer")}
                      className={`px-3 py-1.5 rounded-xl font-bold text-xs ${
                        currentUserRole === "farmer"
                          ? "bg-emerald-555 text-white shadow-xs"
                          : "text-zinc-500"
                      }`}
                    >
                      {lang === "BN" ? "আমি কৃষক" : "Farmer Mode"}
                    </button>
                    <button
                      onClick={() => setCurrentUserRole("expert")}
                      className={`px-3 py-1.5 rounded-xl font-bold text-xs ${
                        currentUserRole === "expert"
                          ? "bg-emerald-555 text-white shadow-xs"
                          : "text-zinc-505"
                      }`}
                    >
                      {lang === "BN" ? "আমি কৃষি কর্মকর্তা" : "Expert Mode"}
                    </button>
                  </div>
                </div>

                {/* Submitting New Report Trigger */}
                {!showCreatePost ? (
                  <button
                    onClick={() => setShowCreatePost(true)}
                    className="w-full py-4 bg-emerald-50 dark:bg-zinc-805 text-emerald-800 dark:text-emerald-400 font-black text-sm sm:text-base border border-emerald-200 dark:border-zinc-800 hover:bg-emerald-100 dark:hover:bg-zinc-800 rounded-2xl flex items-center justify-center gap-2"
                  >
                    <PlusCircle className="w-5 h-5" />
                    {lang === "BN" ? "নতুন ফসলের রোগ বা কৃষি প্রশ্ন শেয়ার করুন" : "Publish new crop observation on Board"}
                  </button>
                ) : (
                  <motion.form
                    onSubmit={handleCreatePostSubmit}
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: "auto" }}
                    className="bg-zinc-50 dark:bg-zinc-950 p-6 rounded-3xl border border-zinc-200 dark:border-zinc-800 space-y-4"
                  >
                    <h3 className="font-extrabold text-sm uppercase">{lang === "BN" ? "আপনার প্রশ্ন লিখুন" : "Create standard crop question form"}</h3>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      <div className="space-y-1">
                        <label className="text-xs text-zinc-400 font-bold">{lang === "BN" ? "ফসলের নাম" : "Crop Identifier"}</label>
                        <input
                          type="text"
                          value={newPostCrop}
                          onChange={(e) => setNewPostCrop(e.target.value)}
                          className="w-full bg-white dark:bg-zinc-900 border p-3 rounded-xl text-xs font-bold"
                          placeholder="e.g. আম চাল বেগুন"
                        />
                      </div>
                      <div className="space-y-1">
                        <label className="text-xs text-zinc-400 font-bold">{lang === "BN" ? "পোস্ট শিরোনাম" : "Question Subject"}</label>
                        <input
                          type="text"
                          value={newPostTitle}
                          onChange={(e) => setNewPostTitle(e.target.value)}
                          className="w-full bg-white dark:bg-zinc-900 border p-3 rounded-xl text-xs font-bold"
                          placeholder={lang === "BN" ? "ধানের পাতা কুঁকড়ে যাওয়া" : "Post Title"}
                          required
                        />
                      </div>
                    </div>

                    <div className="space-y-1">
                      <label className="text-xs text-zinc-400 font-bold">{lang === "BN" ? "বিস্তারিত সমস্যা" : "Detailed description"}</label>
                      <textarea
                        value={newPostContent}
                        onChange={(e) => setNewPostContent(e.target.value)}
                        className="w-full bg-white dark:bg-zinc-900 border p-3 rounded-xl text-xs font-bold min-h-[90px]"
                        placeholder={lang === "BN" ? "আক্রান্ত পাতার রঙ পরিবর্তন ও সার দেয়ার পরও..." : "Describe symptoms, fertilizers, or query..."}
                        required
                      />
                    </div>

                    <div className="flex gap-2.5 justify-end">
                      <button
                        type="button"
                        onClick={() => setShowCreatePost(false)}
                        className="px-4 py-2 bg-zinc-200 dark:bg-zinc-800 rounded-xl font-bold text-xs"
                      >
                        {lang === "BN" ? "বাতিল" : "Cancel"}
                      </button>
                      <button
                        type="submit"
                        className="px-5 py-2 bg-emerald-555 text-white rounded-xl font-bold text-xs"
                      >
                        {lang === "BN" ? "পোস্ট করুন" : "Submit Post"}
                      </button>
                    </div>
                  </motion.form>
                )}

                {/* Communty Posts Stream */}
                <div className="space-y-6">
                  {communityPosts.map((post) => (
                    <div
                      key={post.id}
                      className="bg-zinc-50 dark:bg-zinc-850/30 p-5 rounded-3xl border border-zinc-200/60 dark:border-zinc-800 space-y-4"
                    >
                      {/* Author Info */}
                      <div className="flex justify-between items-start">
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 rounded-full bg-emerald-100 dark:bg-zinc-805 flex items-center justify-center font-black text-emerald-800 dark:text-emerald-450">
                            👤
                          </div>
                          <div>
                            <span className="font-extrabold text-sm">{post.author}</span>
                            <div className="flex items-center gap-2 text-xs text-zinc-400">
                              <span>📍 {post.district}</span>
                              <span>•</span>
                              <span className="text-emerald-600 bg-emerald-50 dark:bg-zinc-800 px-2 py-0.5 rounded-full text-[10px] font-black uppercase">
                                {post.crop}
                              </span>
                            </div>
                          </div>
                        </div>
                        <span className="text-zinc-400 text-xs">{post.createdAt}</span>
                      </div>

                      {/* Post Content */}
                      <div className="space-y-1.5">
                        <h4 className="font-extrabold text-base text-zinc-850 dark:text-zinc-100">{post.title}</h4>
                        <p className="text-xs sm:text-sm text-zinc-600 dark:text-zinc-350 leading-relaxed">
                          {post.content}
                        </p>
                      </div>

                      <div className="flex gap-4 border-t dark:border-zinc-800/80 pt-3 text-xs">
                        <button
                          onClick={() => handlePostLike(post.id)}
                          className="flex items-center gap-2 text-zinc-500 hover:text-emerald-600 font-extrabold cursor-pointer"
                        >
                          <ThumbsUp className="w-4 h-4" />
                          <span>{post.likes} {lang === "BN" ? "লাইক" : "Likes"}</span>
                        </button>
                        <span className="text-zinc-300">|</span>
                        <div className="flex items-center gap-2 text-zinc-505">
                          <MessageSquare className="w-4 h-4" />
                          <span>{post.comments.length} {lang === "BN" ? "টি উত্তর" : "Responses"}</span>
                        </div>
                      </div>

                      {/* Post comments lists */}
                      {post.comments.length > 0 && (
                        <div className="bg-white dark:bg-zinc-950/40 p-4 rounded-2xl border space-y-3.5">
                          {post.comments.map((comm: any) => (
                            <div key={comm.id} className="text-xs space-y-1 pl-3.5 border-l-2 border-emerald-555">
                              <div className="flex justify-between font-black text-emerald-800 dark:text-emerald-450">
                                <span>{comm.author}</span>
                                <span className="opacity-60 text-[9px]">{comm.createdAt}</span>
                              </div>
                              <p className="text-zinc-600 dark:text-zinc-300 leading-normal">
                                {comm.content}
                              </p>
                            </div>
                          ))}
                        </div>
                      )}

                      {/* Write quick comment bar */}
                      <div className="flex items-center gap-2 pt-1">
                        <input
                          type="text"
                          value={newCommentText[post.id] || ""}
                          onChange={(e) =>
                            setNewCommentText((prev) => ({
                              ...prev,
                              [post.id]: e.target.value
                            }))
                          }
                          onKeyDown={(e) => e.key === "Enter" && handleAddComment(post.id)}
                          placeholder={
                            lang === "BN"
                              ? "আপনার কৃষি পরামর্শ বা সমাধান মন্তব্য করুন..."
                              : "Write your advisory answer response..."
                          }
                          className="flex-grow bg-white dark:bg-zinc-900 border p-2.5 rounded-xl text-xs text-zinc-900 dark:text-white font-bold focus:outline-none"
                        />
                        <button
                          onClick={() => handleAddComment(post.id)}
                          className="bg-emerald-555 text-white py-2.5 px-4 rounded-xl text-xs font-black cursor-pointer"
                        >
                          {lang === "BN" ? "মন্তব্য" : "Answer"}
                        </button>
                      </div>

                    </div>
                  ))}
                </div>
              </div>
            )}

          </motion.div>
        </AnimatePresence>
      </main>

      {/* Persistent Immersive Footer bar */}
      <footer className="mt-12 bg-[#0a2e22] border-t border-emerald-800/20 py-8">
        <div className="max-w-7xl mx-auto px-4 flex flex-col md:flex-row justify-between items-center gap-6 text-emerald-300">
          
          <div className="text-center md:text-left space-y-1">
            <h4 className="text-lg font-black text-white">{lang === "BN" ? "কৃষি সহকারী — Bangladesh Smart AI Engine" : "Krishi Shohayok — Digital Agriculture Platform"}</h4>
            <p className="text-xs text-emerald-500 font-bold">
              {lang === "BN" 
                ? "গণপ্রজাতন্ত্রী বাংলাদেশ সরকারের কৃষি সম্প্রসারণ নীতিমালার সাথে সামঞ্জস্য রেখে তৈরি।" 
                : "A modern full-stack web portal optimized for rural network connectivity caches."}
            </p>
          </div>

          <div className="flex items-center gap-4 bg-black/40 rounded-full pr-2 pl-6 py-2.5 border border-emerald-900/40">
            <span className="text-emerald-400 font-medium italic text-xs">
              {lang === "BN" ? `"কিভাবে ইউরিয়া সার সাশ্রয় করব?"` : `"Best low budget potato spray"`}
            </span>
            <button 
              onClick={() => {
                setActiveTab("assistant");
                setChatInput(lang === "BN" ? "কিভাবে ইউরিয়া সার সাশ্রয় করব?" : "How do I save urea fertilizer?");
              }}
              className="w-10 h-10 bg-emerald-500 hover:bg-emerald-450 rounded-full flex items-center justify-center shadow-lg cursor-pointer"
            >
              <Mic className="w-5 h-5 text-black" />
            </button>
          </div>

          <div className="text-xs text-emerald-600 font-bold text-center md:text-right">
            <span>© ২০২৬ কৃত্তিম বুদ্ধিমত্তা কৃষি পোর্টাল। সচল।</span>
          </div>

        </div>
      </footer>
    </div>
  );
}
