import React, { useState, useRef, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Camera, Upload, AlertCircle, RefreshCw, Sparkles, Check, ChevronRight } from "lucide-react";
import { Language, PlantDiseaseResult } from "../types";

interface DiseaseDetectorProps {
  lang: Language;
}

// Low-bandwidth caching simulator
const LOCAL_STORAGE_CACHE_KEY = "krishi_disease_cache";

export const DiseaseDetector: React.FC<DiseaseDetectorProps> = ({ lang }) => {
  const [selectedCrop, setSelectedCrop] = useState<string>("rice");
  const [imageBase64, setImageBase64] = useState<string | null>(null);
  const [isCameraActive, setIsCameraActive] = useState<boolean>(false);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [result, setResult] = useState<PlantDiseaseResult | null>(null);
  const [cachedScans, setCachedScans] = useState<any[]>([]);

  const videoRef = useRef<HTMLVideoElement | null>(null);
  const streamRef = useRef<MediaStream | null>(null);

  // Load cached scans on mount
  useEffect(() => {
    const saved = localStorage.getItem(LOCAL_STORAGE_CACHE_KEY);
    if (saved) {
      try {
        setCachedScans(JSON.parse(saved));
      } catch (e) {
        console.error(e);
      }
    }
  }, []);

  const saveToCache = (crop: string, analyzedResult: PlantDiseaseResult) => {
    const newEntry = {
      id: Date.now().toString(),
      crop,
      timestamp: new Date().toLocaleDateString(lang === "BN" ? "bn-BD" : "en-US"),
      diseaseNameBN: analyzedResult.diseaseNameBangla,
      diseaseNameEN: analyzedResult.diseaseNameEnglish,
      confidence: analyzedResult.confidence,
      detail: analyzedResult
    };
    const updated = [newEntry, ...cachedScans.slice(0, 4)];
    setCachedScans(updated);
    localStorage.setItem(LOCAL_STORAGE_CACHE_KEY, JSON.stringify(updated));
  };

  const startCamera = async () => {
    setError(null);
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: "environment" }
      });
      streamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        videoRef.current.play();
      }
      setIsCameraActive(true);
    } catch (err: any) {
      setError(
        lang === "BN"
          ? "ক্যামেরা সচল করা যাচ্ছে না। দয়া করে ব্রাউজারের অনুমতি চেক করুন।"
          : "Could not activate camera. Please check browser camera permissions."
      );
    }
  };

  const stopCamera = () => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => track.stop());
      streamRef.current = null;
    }
    setIsCameraActive(false);
  };

  const capturePhoto = () => {
    if (videoRef.current) {
      const canvas = document.createElement("canvas");
      canvas.width = 640;
      canvas.height = 480;
      const ctx = canvas.getContext("2d");
      if (ctx) {
        ctx.drawImage(videoRef.current, 0, 0, canvas.width, canvas.height);
        const dataUrl = canvas.toDataURL("image/jpeg", 0.82);
        setImageBase64(dataUrl);
        stopCamera();
      }
    }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        if (typeof reader.result === "string") {
          setImageBase64(reader.result);
        }
      };
      reader.readAsDataURL(file);
    }
  };

  // Analyze crop disease using full-stack API
  const analyzeDisease = async (base64Payload = imageBase64) => {
    if (!base64Payload) {
      setError(lang === "BN" ? "দয়া করে ফলের বা পাতার একটি ছবি সংযুক্ত করুন।" : "Please frame or upload an image.");
      return;
    }

    setIsLoading(true);
    setError(null);
    setResult(null);

    try {
      const response = await fetch("/api/detect-disease", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          crop: selectedCrop,
          imageBase64: base64Payload
        })
      });

      if (!response.ok) {
        throw new Error(lang === "BN" ? "সার্ভার রেসপন্স ব্যর্থ হয়েছে।" : "Server failed to analyze crop.");
      }

      const info: PlantDiseaseResult = await response.json();
      setResult(info);
      saveToCache(selectedCrop, info);
    } catch (err: any) {
      setError(
        lang === "BN"
          ? "বিশ্লেষণে সমস্যা হয়েছে। দয়া করে পুনরায় চেষ্টা করুন।"
          : "AI Analysis failed. Please try again with a clear photo."
      );
    } finally {
      setIsLoading(false);
    }
  };

  const loadFromHistory = (item: any) => {
    setSelectedCrop(item.crop);
    setResult(item.detail);
    setImageBase64(null);
  };

  // Predefined realistic crop template samples to allow instant offline and online testing
  const SAMPLES = [
    {
      id: "samp1",
      crop: "rice",
      nameBN: "ধানের নমুনা (Rice Blast)",
      nameEN: "Rice Sample (Blast)",
      imgColor: "bg-emerald-950",
      svgPath: "M12 2L4 12V22H20V12L12 2Z",
      mockBase64: `data:image/jpeg;base64,/9j/4AAQSkZJRgABAQEASABIAAD/2wBDAP//////////////////////////////////////////////////////////////////////////////////////wgALCAABAAEBAREA/8QAFBABAAAAAAAAAAAAAAAAAAAAAP/aAAgBAQABPxA=`
    },
    {
      id: "samp2",
      crop: "potato",
      nameBN: "আলুর নমুনা (Late Blight)",
      nameEN: "Potato Sample (Blight)",
      imgColor: "bg-amber-950",
      svgPath: "M12 2A10 10 0 1 0 22 12A10 10 0 0 0 12 2Z",
      mockBase64: `data:image/jpeg;base64,/9j/4AAQSkZJRgABAQEASABIAAD/2wBDAP//////////////////////////////////////////////////////////////////////////////////////wgALCAABAAEBAREA/8QAFBABAAAAAAAAAAAAAAAAAAAAAP/aAAgBAQABPxA=`
    }
  ];

  return (
    <div className="space-y-6">
      {/* Crop Selector Card */}
      <div className="bg-white dark:bg-zinc-900 border border-emerald-100 dark:border-zinc-800 rounded-3xl p-5 shadow-sm">
        <h2 className="text-xl font-bold text-zinc-900 dark:text-white mb-3 flex items-center gap-2">
          <Sparkles className="w-5 h-5 text-emerald-500" />
          {lang === "BN" ? "ফসল বা রোগ বালাই নির্বাচন করুন" : "Select Crop and Disease Target"}
        </h2>
        <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-2">
          {[
            { id: "rice", labelBN: "ধান", labelEN: "Rice" },
            { id: "potato", labelBN: "আলু", labelEN: "Potato" },
            { id: "wheat", labelBN: "গম", labelEN: "Wheat" },
            { id: "mango", labelBN: "আম", labelEN: "Mango" },
            { id: "jute", labelBN: "পাট", labelEN: "Jute" },
            { id: "vegetables", labelBN: "সবজি", labelEN: "Vegetables" },
            { id: "fish", labelBN: "মাছ চাষ", labelEN: "Fish Farm" }
          ].map(item => (
            <button
              key={item.id}
              onClick={() => {
                setSelectedCrop(item.id);
                setResult(null);
              }}
              className={`py-3 px-3 rounded-2xl font-bold transition-all text-sm border flex flex-col items-center justify-center gap-1 ${
                selectedCrop === item.id
                  ? "bg-emerald-550 border-emerald-550 text-white shadow-md shadow-emerald-200 dark:shadow-none"
                  : "bg-zinc-50 dark:bg-zinc-800/50 border-zinc-200 dark:border-zinc-800 text-zinc-700 dark:text-zinc-350 hover:bg-emerald-50"
              }`}
            >
              <span className="text-base font-black">
                {lang === "BN" ? item.labelBN : item.labelEN}
              </span>
            </button>
          ))}
        </div>
      </div>

      {/* Main Detector Workspace */}
      <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
        {/* Left Side: Capture & Camera Frame */}
        <div className="md:col-span-6 space-y-4">
          <div className="bg-white dark:bg-zinc-900 border border-emerald-100 dark:border-zinc-800 rounded-3xl p-5 shadow-sm overflow-hidden flex flex-col justify-between min-h-[350px]">
            <div>
              <h3 className="font-bold text-zinc-800 dark:text-zinc-100 text-lg mb-2">
                {lang === "BN" ? "আক্রান্ত পাতার ছবি ক্যামেরা বা ফাইল দিয়ে যোগ করুন" : "Add affected leaf photo"}
              </h3>
              <p className="text-zinc-500 text-sm mb-4">
                {lang === "BN"
                  ? "সরাসরি ক্যামেরা দিয়ে ছবি তুলুন অথবা গ্যালারি থেকে আপলোড করুন।"
                  : "Quickly capture live leaf or choose image from your files."}
              </p>
            </div>

            {/* Viewfinder or Image Preview Box */}
            <div className="relative w-full aspect-video bg-zinc-950 rounded-2xl overflow-hidden flex flex-col items-center justify-center border border-zinc-200 dark:border-zinc-800 shadow-inner">
              {isCameraActive ? (
                <video
                  ref={videoRef}
                  className="w-full h-full object-cover"
                  playsInline
                  muted
                />
              ) : imageBase64 ? (
                <img
                  src={imageBase64}
                  alt="Crop leaves preview"
                  className="w-full h-full object-contain"
                />
              ) : (
                <div className="text-center p-6 space-y-2">
                  <div className="w-16 h-16 rounded-full bg-emerald-50 dark:bg-zinc-800 flex items-center justify-center mx-auto mb-2 text-emerald-500">
                    <Camera className="w-8 h-8" />
                  </div>
                  <p className="text-zinc-400 text-sm font-semibold">
                    {lang === "BN" ? "কোনো ছবি নেওয়া হয়নি" : "No image captured"}
                  </p>
                </div>
              )}

              {/* Loading Spinner overlay */}
              {isLoading && (
                <div className="absolute inset-0 bg-white/70 dark:bg-black/70 backdrop-blur-xs flex flex-col items-center justify-center gap-2">
                  <RefreshCw className="w-10 h-10 text-emerald-600 animate-spin" />
                  <p className="font-bold text-zinc-900 dark:text-white">
                    {lang === "BN" ? "কৃত্রিম বুদ্ধিমত্তা বিশ্লেষণ করছে..." : "AI Engine Analyzing Leaf..."}
                  </p>
                </div>
              )}
            </div>

            {/* Error Message */}
            {error && (
              <div className="mt-3 bg-red-50 dark:bg-red-950/20 text-red-600 dark:text-red-400 p-3 rounded-2xl flex items-center gap-2 text-sm border border-red-100 dark:border-red-950">
                <AlertCircle className="w-5 h-5 flex-shrink-0" />
                <span>{error}</span>
              </div>
            )}

            {/* Mobile Controls / Action Buttons */}
            <div className="mt-5 grid grid-cols-2 gap-3">
              {isCameraActive ? (
                <button
                  onClick={capturePhoto}
                  className="col-span-2 py-3.5 bg-red-600 hover:bg-red-700 text-white rounded-2xl font-black text-base transition-all flex items-center justify-center gap-2"
                >
                  <Camera className="w-5 h-5" />
                  {lang === "BN" ? "ক্যামেরায় ছবি তুলুন" : "Capture Photo"}
                </button>
              ) : (
                <>
                  <button
                    onClick={startCamera}
                    className="py-3.5 bg-emerald-550 hover:bg-emerald-600 text-white rounded-2xl font-black text-sm transition-all flex items-center justify-center gap-2"
                  >
                    <Camera className="w-4 h-4" />
                    {lang === "BN" ? "ক্যামেরা চালান" : "Live Camera"}
                  </button>

                  <label className="py-3.5 bg-zinc-100 dark:bg-zinc-800 hover:bg-emerald-50 cursor-pointer text-zinc-700 dark:text-zinc-200 rounded-2xl font-black text-sm transition-all flex items-center justify-center gap-2 border border-zinc-200 dark:border-zinc-700 text-center">
                    <Upload className="w-4 h-4" />
                    <span>{lang === "BN" ? "ফাইল বেছে নিন" : "Upload File"}</span>
                    <input
                      type="file"
                      accept="image/*"
                      onChange={handleFileUpload}
                      className="hidden"
                    />
                  </label>
                </>
              )}
            </div>

            {/* AI Diagnose Activation Button */}
            {imageBase64 && !isCameraActive && (
              <button
                onClick={() => analyzeDisease()}
                className="mt-3 w-full py-4 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white rounded-2xl font-black text-lg transition-all flex items-center justify-center gap-2 shadow-lg shadow-emerald-50"
              >
                <Sparkles className="w-5 h-5 animate-pulse" />
                {lang === "BN" ? "এআই দিয়ে রোগ শনাক্ত করুন" : "Identify Plant Disease"}
              </button>
            )}
          </div>

          {/* Quick Offline Testing Samples */}
          <div className="bg-white dark:bg-zinc-900 border border-emerald-100 dark:border-zinc-800 rounded-3xl p-5 shadow-sm">
            <h3 className="font-bold text-zinc-800 dark:text-white text-base mb-3">
              {lang === "BN" ? "নমুনা গাছ ক্লিক করে পরীক্ষা করুন (তাত্ক্ষণিক এআই)" : "Select crop sample to test instantly (Live AI)"}
            </h3>
            <div className="grid grid-cols-2 gap-3">
              {SAMPLES.map(sample => (
                <button
                  key={sample.id}
                  onClick={() => {
                    setSelectedCrop(sample.crop);
                    setImageBase64(sample.mockBase64);
                    analyzeDisease(sample.mockBase64);
                  }}
                  className="p-3 bg-zinc-50 dark:bg-zinc-800/40 rounded-2xl hover:bg-emerald-50 text-left border border-zinc-150 dark:border-zinc-800 font-bold transition-all flex items-center justify-between"
                >
                  <div className="flex items-center gap-2">
                    <span className={`w-8 h-8 rounded-xl ${sample.imgColor} flex items-center justify-center text-white text-xs font-black`}>
                      {sample.crop[0].toUpperCase()}
                    </span>
                    <span className="text-sm text-zinc-700 dark:text-zinc-200">
                      {lang === "BN" ? sample.nameBN : sample.nameEN}
                    </span>
                  </div>
                  <ChevronRight className="w-4 h-4 text-emerald-500" />
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Right Side: 3D Motion result container */}
        <div className="md:col-span-6">
          <AnimatePresence mode="wait">
            {result ? (
              <motion.div
                key="resultsCard"
                initial={{ opacity: 0, scale: 0.9, rotateY: 45 }}
                animate={{ opacity: 1, scale: 1, rotateY: 0 }}
                exit={{ opacity: 0, scale: 0.9, rotateY: -45 }}
                transition={{ type: "spring", stiffness: 100, damping: 15 }}
                className="bg-white dark:bg-zinc-900 border-2 border-emerald-550 rounded-3xl p-6 shadow-xl space-y-4 relative overflow-hidden"
              >
                {/* Confidence Badge */}
                <div className="absolute top-4 right-4 bg-emerald-100 text-emerald-800 font-black px-3 py-1 rounded-full text-xs flex items-center gap-1">
                  <Check className="w-3.5 h-3.5" />
                  {result.confidence}% {lang === "BN" ? "নিশ্চিত" : "Confidence"}
                </div>

                <div>
                  <span className="text-zinc-400 text-xs font-black tracking-widest uppercase">
                    {lang === "BN" ? "এআই রোগ বিশ্লেষণ" : "AI Disease Diagnosis"}
                  </span>
                  <h3 className="text-2xl font-black text-emerald-700 dark:text-emerald-450 mt-1">
                    {result.diseaseNameBangla}
                  </h3>
                  <p className="text-zinc-500 text-sm font-semibold italic">
                    {result.diseaseNameEnglish}
                  </p>
                </div>

                <hr className="border-zinc-100 dark:border-zinc-800" />

                {/* Symptoms */}
                <div>
                  <h4 className="font-extrabold text-zinc-800 dark:text-zinc-200 text-sm mb-1.5 flex items-center gap-2">
                    <span className="w-2 h-2 rounded-full bg-orange-500" />
                    {lang === "BN" ? "লক্ষণসমূহ" : "Symptoms"}
                  </h4>
                  <ul className="text-zinc-600 dark:text-zinc-350 text-sm space-y-1 list-disc list-inside">
                    {result.symptoms.map((sym, idx) => (
                      <li key={idx} className="leading-relaxed">{sym}</li>
                    ))}
                  </ul>
                </div>

                {/* Organic Solutions */}
                <div className="bg-emerald-50/60 dark:bg-emerald-950/10 p-4 rounded-2xl border border-emerald-100/50 dark:border-emerald-950/40">
                  <h4 className="font-black text-emerald-800 dark:text-emerald-400 text-sm mb-1.5 flex items-center gap-1.5">
                    🌱 {lang === "BN" ? "জৈবিক সমাধান (কম খরচ)" : "Organic Solutions (Low Budget)"}
                  </h4>
                  <ul className="text-emerald-900 dark:text-emerald-300 text-sm space-y-1 list-disc list-inside">
                    {result.solutionsOrganic.map((sol, idx) => (
                      <li key={idx} className="leading-relaxed">{sol}</li>
                    ))}
                  </ul>
                </div>

                {/* Chemical Solutions */}
                <div className="bg-amber-50/40 dark:bg-amber-950/15 p-4 rounded-2xl border border-amber-100/40 dark:border-amber-900/10">
                  <h4 className="font-black text-amber-800 dark:text-amber-400 text-sm mb-1.5 flex items-center gap-1.5">
                    🧪 {lang === "BN" ? "রাসায়নিক স্প্রে ও সমাধান" : "Chemical Spray & Solutions"}
                  </h4>
                  <ul className="text-amber-900 dark:text-amber-300 text-sm space-y-1 list-disc list-inside">
                    {result.solutionsChemical.map((sol, idx) => (
                      <li key={idx} className="leading-relaxed">{sol}</li>
                    ))}
                  </ul>
                </div>

                {/* Prevention */}
                <div>
                  <h4 className="font-extrabold text-zinc-800 dark:text-zinc-200 text-sm mb-1.5 flex items-center gap-1.5">
                    🛡️ {lang === "BN" ? "প্রতিরোধমূলক টিপস" : "Prevention Tips"}
                  </h4>
                  <ul className="text-zinc-600 dark:text-zinc-350 text-sm space-y-1 list-disc list-inside">
                    {result.prevention.map((prev, idx) => (
                      <li key={idx} className="leading-relaxed">{prev}</li>
                    ))}
                  </ul>
                </div>

                <button
                  onClick={() => setResult(null)}
                  className="w-full py-3 bg-zinc-50 dark:bg-zinc-800 text-zinc-600 dark:text-zinc-300 rounded-2xl font-extrabold text-sm border hover:bg-zinc-100 transition-all"
                >
                  {lang === "BN" ? "নতুন করে স্ক্যান করুন" : "Scan Another Crop"}
                </button>
              </motion.div>
            ) : (
              <div className="bg-zinc-50 dark:bg-zinc-900/50 border border-dashed border-zinc-200 dark:border-zinc-800 rounded-3xl p-8 text-center min-h-[450px] flex flex-col items-center justify-center space-y-4">
                <div className="w-20 h-20 bg-emerald-50 dark:bg-zinc-800 rounded-full flex items-center justify-center text-emerald-500">
                  <Sparkles className="w-10 h-10" />
                </div>
                <h3 className="font-black text-lg text-zinc-850 dark:text-white">
                  {lang === "BN" ? "এআই রিপোর্টের জন্য অপেক্ষা করছে" : "Waiting for diagnosis report"}
                </h3>
                <p className="text-zinc-500 max-w-sm text-sm">
                  {lang === "BN"
                    ? "বাম পাশের ক্যানভাসে একটি ফসলের ছবি ক্যাপচার অথবা আপলোড করুন। এআই স্বয়ংক্রিয়ভাবে রোগ ও তার সহজ সমাধান প্রদান করবে।"
                    : "Capture the affected leaf photo and request AI advice. It calculates both organic & chemical treatment options instantly."}
                </p>

                {/* Low connectivity cache logs */}
                {cachedScans.length > 0 && (
                  <div className="w-full text-left pt-6 border-t border-zinc-200/50 dark:border-zinc-800">
                    <h4 className="text-xs font-black tracking-widest text-zinc-400 uppercase mb-3 text-center">
                      📂 {lang === "BN" ? "অফলাইন সংরক্ষিত স্ক্যানসমূহ" : "Offline Cached Scans"}
                    </h4>
                    <div className="space-y-2">
                      {cachedScans.map(item => (
                        <div
                          key={item.id}
                          onClick={() => loadFromHistory(item)}
                          className="p-3 bg-white dark:bg-zinc-900 rounded-2xl border border-emerald-50 dark:border-zinc-850 hover:bg-emerald-50 hover:border-emerald-250 cursor-pointer flex justify-between items-center transition-all shadow-xs"
                        >
                          <div>
                            <div className="font-black text-sm text-emerald-700 dark:text-emerald-450">
                              {item.crop[0].toUpperCase() + item.crop.slice(1)}: {item.diseaseNameBN}
                            </div>
                            <div className="text-xs text-zinc-400">
                              {item.timestamp}
                            </div>
                          </div>
                          <span className="text-xs font-bold text-zinc-500 bg-zinc-100 dark:bg-zinc-800 px-2 py-0.5 rounded-full">
                            {lang === "BN" ? "দেখুন" : "View"}
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            )}
          </AnimatePresence>
        </div>
      </div>
    </div>
  );
};
