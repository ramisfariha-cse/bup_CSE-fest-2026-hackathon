import express from "express";
import path from "path";
import dotenv from "dotenv";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI, Type } from "@google/genai";

dotenv.config();

const app = express();
const PORT = 3000;

// Set up server-side maximum payload limit for processing uploaded plant images
app.use(express.json({ limit: "20mb" }));
app.use(express.urlencoded({ extended: true, limit: "20mb" }));

// Lazy initializer for the Gemini client to prevent crashing on boot if key is missing
let aiClient: GoogleGenAI | null = null;
function getGeminiClient(): GoogleGenAI {
  if (!aiClient) {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      console.warn("WARNING: GEMINI_API_KEY environment variable is not set. Using mock fallbacks for client safety.");
    }
    aiClient = new GoogleGenAI({
      apiKey: apiKey || "MOCK_KEY",
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        }
      }
    });
  }
  return aiClient;
}

// ----------------- API ENDPOINTS -----------------

// Helper to determine if we are running in mock mode
const isMockMode = () => !process.env.GEMINI_API_KEY;

// 1. AI Plant Disease Detection
app.post("/api/detect-disease", async (req, res) => {
  try {
    const { crop, imageBase64 } = req.body;
    if (!crop || !imageBase64) {
      return res.status(400).json({ error: "Crop type and crop image are required." });
    }

    if (isMockMode()) {
      // High-quality mock fallback for testing without API keys
      const sampleMocks: Record<string, any> = {
        rice: {
          diseaseNameBangla: "ধানের ব্লাস্ট রোগ (Rice Blast)",
          diseaseNameEnglish: "Rice Blast Disease",
          confidence: 94,
          symptoms: [
            "পাতার উপরে স্পিন্ডেল আকৃতির বা চোখের মতো দাগ পড়ে, মাঝখানটা ধূসর এবং চারপাশটা বাদামী বর্ণের হয়।",
            "আক্রান্ত পাতাগুলো শুকিয়ে মারা যেতে পারে।",
            "ধানের শিষের গোড়ায় আক্রমণ করলে ফুল ও দানা গঠন ব্যাহত হয়।"
          ],
          causes: ["ম্যাগনাপোর্ট ওরিজি (Magnaporthe oryzae) নামক ছত্রাক।", "অতিরিক্ত নাইট্রোজেন সার ব্যবহার এবং স্যাঁতসেঁতে আবহাওয়া।"],
          solutionsOrganic: [
            "নিম পাতার নির্যাস বা সুক্রোজ স্প্রে করুন।",
            "আক্রান্ত জমির পানি সরিয়ে দিন এবং রোদ লাগানোর ব্যবস্থা করুন।"
          ],
          solutionsChemical: [
            "ট্রাইসাইক্লাজল (Tricyclazole) বা ট্রাইসাইক্লাজল+হেক্সাকোনাজল ছত্রাকনাশক প্রতি লিটার পানিতে ১ গ্রাম হারে মিশিয়ে স্প্রে করুন।"
          ],
          prevention: [
            "রোগ প্রতিরোধী ধানের জাত ব্যবহার করুন।",
            "সুষম মাত্রায় ইউরিয়া, টিএসপি এবং পটাশ সার ব্যবহার করুন।"
          ]
        },
        potato: {
          diseaseNameBangla: "আলুর লেট ব্লাইট রোগ (Late Blight of Potato)",
          diseaseNameEnglish: "Late Blight",
          confidence: 96,
          symptoms: [
            "পাতা, কাণ্ড এবং আলুতে ভেজা জ্যাকেট বা কালচে বাদামী দাগ তৈরি হয়।",
            "কুয়াশাচ্ছন্ন শুষ্ক শীতল আবহাওয়ায় দ্রুত ছড়িয়ে পড়ে এবং পাতা পচে যায়।"
          ],
          causes: ["ফাইটোফথোরা ইনফেসট্যান্স (Phytophthora infestans) নামক উপছত্রাক।"],
          solutionsOrganic: [
            "ঘোড়ার মূত্র বা তামা সমৃদ্ধ কম্পোস্ট বা নিম পাতার দ্রবণ ছিটানো।",
            "আক্রান্ত গাছ সাথে সাথে তুলে মাটি চাপা দেওয়া।"
          ],
          solutionsChemical: [
            "ম্যানকোজেব (Mancozeb) বা মেটালেক্সিল গোত্রের ছত্রাকনাশক মাঠে কুয়াশা থাকা অবস্থায় স্প্রে করা।"
          ],
          prevention: [
            "সুস্থ ও প্রত্যয়িত বীজ আলু রোপণ করুন।",
            "আলু গাছে মাটি তুলে দেওয়ার সময় ড্রেনেজ সিস্টেম ভালো রাখুন।"
          ]
        },
        default: {
          diseaseNameBangla: "পাতার ড্যাম্পিং অফ বা ছত্রাকজনিত স্পট",
          diseaseNameEnglish: "Leaf Leaf-Spot Disease",
          confidence: 88,
          symptoms: [
            "পাতার উপরিভাগে লালচে বাদামী বা কালো দাগ।",
            "আক্রান্ত পাতা হলুদ হয়ে আস্তে আস্তে ঝরে পড়া।"
          ],
          causes: ["আর্দ্র আবহাওয়া এবং অতিরিক্ত সেচজনিত ছত্রাক আক্রমণ।"],
          solutionsOrganic: [
            "জৈব ট্রাইকোডার্মা ছিটানো এবং আক্রান্ত পাতা কেটে ধ্বংস করা।"
          ],
          solutionsChemical: [
            "কার্বেন্ডাজিম (Carbendazim) গোত্রের ওষুধ প্রতি লিটার পানিতে ২ গ্রাম মিশিয়ে স্প্রে করা।"
          ],
          prevention: [
            "গাছপালার মাঝে পর্যাপ্ত দূরত্ব বজায় রাখা যাতে সহজে বাতাস চলাচল করতে পারে।"
          ]
        }
      };
      const result = sampleMocks[crop.toLowerCase()] || sampleMocks.default;
      return res.json(result);
    }

    const ai = getGeminiClient();
    // Pre-processing helper for base64 image
    const base64Data = imageBase64.replace(/^data:image\/\w+;base64,/, "");
    const imagePart = {
      inlineData: {
        mimeType: "image/jpeg",
        data: base64Data,
      },
    };

    const promptText = `You are a visionary plant pathologist and senior agricultural scientist in Bangladesh. 
Identify the disease affecting this "${crop}" plant based on the image. 
Return your comprehensive expert analysis in JSON format ONLY matching the following schema.
All translations to Bangla must be perfectly natural, colloquial for rural farmers, and culturally precise. Do not use complex English jargon in the Bangla description.

Output Schema:
{
  "diseaseNameBangla": "Disease Name in Bangla (e.g., ধানের ব্লাস্ট রোগ)",
  "diseaseNameEnglish": "Disease Name in English (e.g., Rice Blast)",
  "confidence": <confidence scale 0 to 100 as integer>,
  "symptoms": ["Symptom 1 in Bangla", "Symptom 2 in Bangla"],
  "causes": ["Cause 1 in Bangla", "Cause 2 in Bangla"],
  "solutionsOrganic": ["Organic treatment 1 in Bangla", "Organic treatment 2 in Bangla"],
  "solutionsChemical": ["Chemical treatment 1 in Bangla", "Chemical treatment 2 in Bangla"],
  "prevention": ["Prevention tip 1 in Bangla", "Prevention tip 2 in Bangla"]
}`;

    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: {
        parts: [imagePart, { text: promptText }]
      },
      config: {
        responseMimeType: "application/json",
      }
    });

    const cleanResultText = response.text || "{}";
    const data = JSON.parse(cleanResultText.trim());
    return res.json(data);

  } catch (error: any) {
    console.error("Disease Detection Error:", error);
    return res.status(500).json({ error: error.message || "ছত্রাকজনিত বিশ্লেষণ ব্যর্থ হয়েছে।" });
  }
});

// 2. Crop & Fertilizer Recommendation Engine
app.post("/api/recommend-crop-fertilizer", async (req, res) => {
  try {
    const { soilType, division, budgetStatus, selectedSeason } = req.body;
    
    if (isMockMode()) {
      // Mock for offline / keyless environments
      const fertMock = {
        recommendedCrops: [
          {
            cropName: "বিআরআরআই ধান ২৯ (BRRI Dhan 29)",
            suitability: "উচ্চ (High)",
            expectedYield: "প্রতি শতকে ২৫-২৮ কেজি",
            farmingDuration: "১৪০-১৫০ দিন"
          },
          {
            cropName: "সরিষা (Mustard - BINA-9)",
            suitability: "মাঝারি (Medium)",
            expectedYield: "প্রতি শতকে ৭-৮ কেজি",
            farmingDuration: "৮০-৯০ দিন"
          }
        ],
        fertilizerRoutine: [
          { name: "ইউরিয়া (Urea)", amount: "প্রতি শতকে ৮০০ গ্রাম", timing: "৩ কিস্তিতে প্রয়োগ (গাছ রোপণের ১৫, ৩০ ও ৪৫ দিন পর)" },
          { name: "টিএসপি (TSP)", amount: "প্রতি শতকে ৪০০ গ্রাম", timing: "জমি তৈরির শেষ চাষের সময়" },
          { name: "এমওপি বা পটাশ (MOP)", amount: "প্রতি শতকে ৫০০ গ্রাম", timing: "জমি তৈরি এবং শেষ কিস্তি উপরি প্রয়োগ" },
          { name: "জৈব কম্পোস্ট (Organic Compost)", amount: "প্রতি শতকে ৫ কেজি", timing: "জমি তৈরির প্রথম চাষের সময়" }
        ],
        costOptimizationTips: [
          "রাসায়নিক সারের অপচয় কমাতে গুটি ইউরিয়া ব্যবহার করতে পারেন যাতে খরচ ৩০% কমে যাবে।",
          "সবুজ সার যেমন ধঞ্চে চাষ করে মাটিতে মিশিয়ে দিলে নাইট্রোজেনের খরচ হ্রাস পাবে।",
          "সুষম সার ব্যবহারে মাটি ভালো থাকে এবং অতিরিক্ত সারের অপচয় রোখা যায়।"
        ]
      };
      return res.json(fertMock);
    }

    const ai = getGeminiClient();
    const promptText = `You are the chief agricultural consultant of the Bangladesh Soil Resource Development Institute (SRDI). 
Based on these inputs:
- Soil type: ${soilType}
- Division/Region: ${division}
- Budget Category: ${budgetStatus} (Low Budget, Medium, Advanced)
- Season: ${selectedSeason}

Provide optimal crop and fertilizer suggestions tailored for Bangladeshi micro-farming environments in JSON format.
Output Schema:
{
  "recommendedCrops": [
    { "cropName": "Crop name in Bangla", "suitability": "High/Medium in Bangla", "expectedYield": "Estimated yield per decimal/bigha in Bangla", "farmingDuration": "Duration in Bangla" }
  ],
  "fertilizerRoutine": [
    { "name": "Fertilizer Name in Bangla (e.g. ইউরিয়া, টিএসপি)", "amount": "Required dosage in Bangla", "timing": "Instructions when to apply in Bangla" }
  ],
  "costOptimizationTips": [
    "Tip 1 in Bangla to save money on fertilizers",
    "Tip 2 in Bangla explaining smart compost or alternate wetting systems"
  ]
}`;

    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: promptText,
      config: {
        responseMimeType: "application/json"
      }
    });

    const cleanResultText = response.text || "{}";
    const data = JSON.parse(cleanResultText.trim());
    return res.json(data);

  } catch (error: any) {
    console.error("Recommendation Error:", error);
    return res.status(500).json({ error: "প্রস্তাবনা জেনারেট করা সম্ভব হয়নি।" });
  }
});

// 3. Live Market Price Trend & Analysis Proxy
app.post("/api/market-trends", async (req, res) => {
  try {
    const { crop, district } = req.body;

    if (isMockMode()) {
      // Return beautiful market mock stats
      return res.json({
        currentPrice: "৪০ - ৪৫ টাকা/কেজি",
        lastWeekPrice: "৩৮ টাকা/কেজি",
        predictedNextMonthPrice: "৪৮ - ৫২ টাকা/কেজি",
        trendDirection: "UP", // UP, DOWN, STABLE
        districtMarketNames: [
          { market: `${district} সদর আড়ত ও কাঁচাবাজার`, distance: "৩ কিমি দূরে", price: "৪২ টাকা/кеজি" },
          { market: "কারওয়ান বাজার, ঢাকা (পাইকারি)", distance: "দূরবর্তী সর্বোচ্চ লাভ", price: "৪৮ টাকা/কেজি" }
        ],
        aiAnalysis: `বর্তমানে ${district} এলাকায় এই ফসলের সরবরাহ ক্রমান্বয়ে স্বাভাবিক রয়েছে। তবে বর্ষার আগমনে এবং পরিবহন ব্যয়ের ঊর্ধ্বগতির কারণে আগামী ৪ সপ্তাহে বাজারে দাম ১০% থেকে ১৫% বৃদ্ধি পেতে পারে। আড়তদারদের কাছে সরাসরি বিক্রি না করে স্থানীয় সমবায় বাজারে বিক্রি করলে বেশি লাভবান হওয়া সম্ভব।`
      });
    }

    const ai = getGeminiClient();
    const promptText = `Analyze the market scenario in Bangladesh for "${crop}" specifically in district "${district}". Include local market rates, prediction for the next 4 weeks, and optimize selling advice.
Return ONLY in JSON format matching this schema:
{
  "currentPrice": "Bangla price range (e.g., ৪৫-৫০ টাকা/কেজি)",
  "lastWeekPrice": "Bangla price (e.g., ৪২ টাকা/কেজি)",
  "predictedNextMonthPrice": "Bangla price (e.g., ৫৫-৬০ টাকা/কেজি)",
  "trendDirection": "UP or DOWN or STABLE",
  "districtMarketNames": [
    { "market": "Local Market Name in Bangla", "distance": "Distance / Reach in Bangla", "price": "Rate in Bangla" }
  ],
  "aiAnalysis": "Comprehensive AI price trend commentary and marketing strategy for small farmers in Bangla."
}`;

    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: promptText,
      config: {
        responseMimeType: "application/json"
      }
    });

    const cleanResultText = response.text || "{}";
    const data = JSON.parse(cleanResultText.trim());
    return res.json(data);

  } catch (error: any) {
    console.error("Market Trends Error:", error);
    return res.status(500).json({ error: "বাজার বিশ্লেষণ লোড করা সম্ভব হয়নি।" });
  }
});

// 4. Bangla Voice Q&A Assistant Router
app.post("/api/farmer-assistance", async (req, res) => {
  try {
    const { question, history } = req.body;
    if (!question) {
      return res.status(400).json({ error: "প্রশ্ন আবশ্যক।" });
    }

    if (isMockMode()) {
      return res.json({
        answer: `আপনার প্রশ্নটির জন্য ধন্যবাদ! কৃষি সহকারীর পক্ষ থেকে আপনার জন্য পরামর্শ হলো: সাধারণত এই সময়ে মাটিতে পর্যাপ্ত আর্দ্রতা কমে যায়। তাই বিকেলের দিকে পরিমিত সেচ দিন। গাছে কোনো রোগ বা সাদা পোকার আক্রমণ দেখলে নিম তেলের স্প্রে করতে পারেন। আরও কোনো নির্দিষ্ট ফসলের রোগ শনাক্তকরণে রোগ বালাই ট্যাব থেকে ছবি আপলোড করুন।`
      });
    }

    const ai = getGeminiClient();
    const formattedHistory = (history || []).map((h: any) => `${h.sender === "user" ? "Farmer" : "Assistant"}: ${h.text}`).join("\n");
    
    const promptText = `You are "মাটি ও মানুষ" (Mati o Manush), an exceptionally compassionate, wise, and helpful veteran Agricultural Extension Officer and crop expert in Bangladesh.
You speak only in beautiful, colloquial, warm Bangla language suitable for rural Bangladeshi farmers.
Provide incredibly practical, organic-first, cheap solutions to the query. Answer shortly in 3 to 5 easy sentences so it is very easy to read or read out loud via screen reader.

Discussion Context:
${formattedHistory}
Farmer query: ${question}

Response Schema:
{
  "answer": "Your warm expert guidance in clear Bangla."
}`;

    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: promptText,
      config: {
        responseMimeType: "application/json"
      }
    });

    const cleanResultText = response.text || "{}";
    const data = JSON.parse(cleanResultText.trim());
    return res.json(data);

  } catch (error: any) {
    console.error("Assistant Error:", error);
    return res.status(500).json({ error: "ভয়েস সমাধান তৈরি করতে সমস্যা হয়েছে।" });
  }
});


// ----------------- VITE MIDDLEWARE CONFIG -----------------

async function startServer() {
  // Mount Vite server in development or provide static files in production
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Agriculture Full-Stack Server running on port ${PORT}`);
  });
}

startServer().catch((err) => {
  console.error("Failed to start agricultural server:", err);
});
